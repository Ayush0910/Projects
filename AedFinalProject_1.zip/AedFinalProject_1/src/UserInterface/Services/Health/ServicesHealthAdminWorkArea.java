/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.Services.Health;

import UserInterface.Services.Education.*;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.FundWorkQueue.FundRequestWorkRequest;
import Business.FundWorkQueue.FundWorkRequest;
import Business.FundWorkQueue.FundWorkWorkRequest;
import Business.FundWorkQueue.HealthFundWorkRequest;
import Business.FundWorkQueue.QuotationAnsWorkRequest;
import Business.FundWorkQueue.ReportFundWorkRequest;
import Business.FundWorkQueue.ServiceReportWorkRequest;
import Business.FundWorkQueue.ServiceRequestWorkrequest;
import Business.Organization.EducationInstitutionOrganization;
import Business.Organization.HealthClinicOrganization;
import Business.Organization.Organization;
import Business.Organization.RehabFunderOrganization;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author maila
 */
public class ServicesHealthAdminWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form ServicesHealthAdminWorkArea
     */
    JPanel userProcessContainer;
    EcoSystem system;
    HealthClinicOrganization organization;
    UserAccount account;
    Enterprise enterprise;
    public ServicesHealthAdminWorkArea(JPanel userProcessContainer,EcoSystem system, HealthClinicOrganization organization,UserAccount account,Enterprise enterprise) {
        initComponents();
        this.userProcessContainer=userProcessContainer;
        this.account=account;
        this.enterprise=enterprise;
        this.organization=organization;
        this.system=system;
        
        populateTable();        
        populateTable2();       
        populateTable3();
        
        
        
     for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
         if(request instanceof ServiceRequestWorkrequest && request.getMessage().equalsIgnoreCase("Health"))
        populateTable7();
    }
        
    
   
    
public void populateTable(){
        DefaultTableModel model = (DefaultTableModel)Table.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
           if(request instanceof HealthFundWorkRequest)
            if(request.getMessage().equalsIgnoreCase("Health Clinic") && request.getCategory().equalsIgnoreCase("Health Funder")) 
                
               {
           
                
            Object[] row = new Object[6];   
            
            row[0] = request.getSender().getEmployee().getName();
            row[1] = request.getReceiver();
            row[2] = request;
            row[3] = request.getPriority();
            row[4] = request.getReqId();
            model.addRow(row);
        
        }
    }  

 int fund=0;
 List<Integer> id=new ArrayList<>();
 
public int calculateFunds()
{
    for(Organization org : enterprise.getOrganizationDirectory().getOrganizationList()){
       id.add(org.getOrganizationID());    
    
    }
   
    for(int i=0; i<id.size();i++)
        
   for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
       
           if(request.getMessage().equalsIgnoreCase("Calculating Health Funds") ) 
        {
            
            if(((HealthFundWorkRequest) request).getType().equalsIgnoreCase("Normal"))
                fund=(i+300)+(int)(Math.random()*100);
            else if(((HealthFundWorkRequest) request).getType().equalsIgnoreCase("Imaging and Nursing"))
                fund=(i+500)+(int)(Math.random()*100);
            else if(((HealthFundWorkRequest) request).getType().equalsIgnoreCase("organs"))
                fund=(i+1500)+(int)(Math.random()*100);
            else if(((HealthFundWorkRequest) request).getType().equalsIgnoreCase("cancer"))
                fund=(i+2200)+(int)(Math.random()*100);
            
            
        }
   return fund;
}

 List<Integer> priority = new ArrayList<>();
            int minm = 0;
           
       public int priorityCal()
       {
          for(FundWorkRequest req: system.getFundWorkQueue().getWorkRequestList())
          
          if(req.getReceiver()==null || req.getReceiver().getEmployee().getName().isEmpty() && req.getPriMsg().equalsIgnoreCase("Health priority"))
              {
                  if(req.getPriority()>0)
              priority.add(req.getPriority());
              }
              else if(req.getRec().size()>0)
              for(UserAccount a:req.getRec()){
                  if(a.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()) || a.getEmployee().getName().isEmpty() && req.getPriMsg().equalsIgnoreCase("Health priority")){
              if(req.getPriority()>0)
              priority.add(req.getPriority()); 
                  }
                  else  if(!(a.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()) || a.getEmployee().getName().isEmpty()) && req.getPriMsg().equalsIgnoreCase("Health priority")){
              if(req.getPriority()>0)
              priority.add(req.getPriority()); 
                  }
              }
          minm=Collections.min(priority);
          return minm;
          
       }
       
       
public void populateTable2()
{
  DefaultTableModel dtm=(DefaultTableModel) Table1.getModel();
    dtm.setRowCount(0);
    for(FundWorkRequest req:system.getFundWorkQueue().getWorkRequestList())
    {
        if(req instanceof QuotationAnsWorkRequest)
        if(req.getMessage().equalsIgnoreCase("Hea") )
        for(UserAccount a : ((QuotationAnsWorkRequest) req).getSen1()) 
        if(a.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()))
                {
            
        Object[] row = new Object[8];
        row[0]=a.getEmployee().getName();
        row[1]=req.getReceiver();
        row[2]=req;
        row[3]=((QuotationAnsWorkRequest) req).getFund();
        row[4]=req.getReqId();
        dtm.addRow(row);
        }
    }
}

    public void populateTable3()
    {
       DefaultTableModel dtm=(DefaultTableModel) Table2.getModel();
    dtm.setRowCount(0);
    for(FundWorkRequest req:system.getFundWorkQueue().getWorkRequestList())
    {
        if(req instanceof ServiceRequestWorkrequest){
      if(req.getMessage().equalsIgnoreCase("Health") && req.getFundCategory().equalsIgnoreCase(account.getEmployee().getName())){
        Object[] row = new Object[8];
        row[0]=req.getSender();
        row[1]=req.getReceiver();
        row[2]=req;
        row[3]=req.getReqId();
        
        dtm.addRow(row);
        }
    } 
    }
    }
    
    public void populateTable4()
{
    DefaultTableModel dtm=(DefaultTableModel) Table.getModel();
    dtm.setRowCount(0);
    
    for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())              
            if(request.getMessage().equalsIgnoreCase("Calculating Health Funds"))
            for(UserAccount a: request.getRec())
                if(a.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()))
    {
        Object[] row = new Object[6];
            row[0] = request.getSender().getEmployee().getName();
            row[1] = a.getEmployee().getName();
            row[2] = request;
            row[3] = request.getPriority();
            row[4] = request.getReqId();
        
        dtm.addRow(row);
    }
}
      public void populateTable5()
{
    DefaultTableModel dtm=(DefaultTableModel) Table.getModel();
    dtm.setRowCount(0);
    
    for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())              
            if(request.getMessage().equalsIgnoreCase("Hea"))
            for(UserAccount a: request.getRec())
                if(a.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()))
                    for(UserAccount a1:((QuotationAnsWorkRequest) request).getSen1())
    {
        Object[] row = new Object[5];
            row[0]=a1.getEmployee().getName();
            row[1] = a.getEmployee().getName();
            row[2] = request;
            row[3] = request.getPriority();
            row[4] = request.getReqId();
        
        dtm.addRow(row);
    }
}
      public void populateTable6()
{
    DefaultTableModel dtm=(DefaultTableModel) Table.getModel();
    dtm.setRowCount(0);
    
    for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())              
            if(request.getMessage().equalsIgnoreCase("Calculating Health Funds") )
            
               
    {
        Object[] row = new Object[6];
            row[0] = request.getSender();
            row[1] = null;
            row[2] = request;            
            row[3] = request.getPriority();
            row[4] = request.getReqId();
            
       
        
        dtm.addRow(row);
    }
}
    
      public void populateTable7(){
        DefaultTableModel model = (DefaultTableModel)Table1.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
            if(request instanceof ServiceRequestWorkrequest)
                if(request.getMessage().equalsIgnoreCase("Health") && request.getFundCategory().equalsIgnoreCase(account.getEmployee().getName()))
                               
               {          
                
            Object[] row = new Object[6];   
            
            row[0] = request.getReceiver();
            row[1] = request.getSender().getEmployee().getName();
            row[2] = request;
            row[3] = request.getFund();
            row[4] = request.getReqId();
            
            model.addRow(row);
        
        }
    }  
      
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        sendBtn = new javax.swing.JButton();
        calculateBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Table1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Table2 = new javax.swing.JTable();
        assignToMeBtn = new javax.swing.JButton();
        completeBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED)), "REQUEST FOR FUND QUOTATION"));

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Reciever", "Status", "Priority", "Request ID"
            }
        ));
        jScrollPane1.setViewportView(Table);

        sendBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        sendBtn.setText("SEND");
        sendBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        sendBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendBtnActionPerformed(evt);
            }
        });

        calculateBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        calculateBtn.setText("CALCULATE");
        calculateBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        calculateBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        calculateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(calculateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1019, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(102, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(calculateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 160, -1, 290));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED)), "RESPONSE TO FUNDER"));

        Table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Reciever", "Status", "Fund", "Request Id"
            }
        ));
        jScrollPane2.setViewportView(Table1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(111, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, -1, 270));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED)), "REQUEST FROM FUNDER"));

        Table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Reciever", "Status", "Request Id"
            }
        ));
        jScrollPane3.setViewportView(Table2);

        assignToMeBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        assignToMeBtn.setText("ASSIGN TO ME");
        assignToMeBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignToMeBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        assignToMeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignToMeBtnActionPerformed(evt);
            }
        });

        completeBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        completeBtn.setText("COMPLETE");
        completeBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        completeBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        completeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(96, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(assignToMeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(completeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignToMeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(completeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(105, 105, 105))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 460, -1, 270));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("HEALTH SERVICES WORK AREA");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/Services/Education/health-management-icon.png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1598, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 1880, 140));
    }// </editor-fold>//GEN-END:initComponents

    private void calculateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateBtnActionPerformed
        // TODO add your handling code here:
        int selectedRow= Table.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
     return;
         }else{
        FundWorkRequest request = (FundWorkRequest) Table.getValueAt(selectedRow, 2);
        if(request.getStatus().equalsIgnoreCase("Sent"))
            if(request.getRec().size()>0){
        for(UserAccount a1:request.getRec())
        if(!(a1.getEmployee().getName().equalsIgnoreCase(account.getEmployee().getName()))){
         priorityCal();
         if(request.getPriority()==0)
         {
             JOptionPane.showMessageDialog(null, "Cannot Do the calculation twice!!!!!");
         }
            if(request.getPriority()==minm) {
         
         
            
       
        
        request.setReceiver(account);
        request.getRec().add(account);
        request.setStatus("Calculating");
        request.setMessage("Calculating Health Funds");
        request.setPriMsg("Health priority");
       
        populateTable4();
         }else{
             JOptionPane.showMessageDialog(null, "Serve Minimum Priority First");
         }
        }
            
         }else{
               
         
         
            
       
        request.setReceiver(account);
        request.getRec().add(account);
        request.setStatus("Calculating");
        request.setMessage("Calculating Health Funds");
       request.setPriMsg("Health priority");
        populateTable4();
         }
        
            }
    
        
    }//GEN-LAST:event_calculateBtnActionPerformed

    private void sendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendBtnActionPerformed
        // TODO add your handling code here:
         int selectedRow= Table.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
     return;
         }else{
          FundWorkRequest request = (FundWorkRequest) Table.getValueAt(selectedRow, 2);
          
          if(request.getMessage().equalsIgnoreCase("Calculating Health Funds")){
              calculateFunds();   
        QuotationAnsWorkRequest req=new QuotationAnsWorkRequest();
       
        req.getRec().add(account);
        req.getSen1().add(account);
        req.setStatus("Sent");
        req.setFund(fund);
        req.setMessage("Hea");
        req.setReqId(request.getReqId());
        request.setStatus("Sent");
        req.setReqName(request.getReqName());
        req.setReqEmp(request.getReqEmp());
        req.setPriority(request.getPriority());
        req.setStat("done Health");
        req.setPriMsg(request.getPriMsg());
        
        organization.getFundWorkQueue().getWorkRequestList().add(req);
        account.getFundWorkQueue().getWorkRequestList().add(req);
        system.getFundWorkQueue().getWorkRequestList().add(req);
        populateTable5();
        populateTable2();
        
        JOptionPane.showMessageDialog(null, "Request with Quotation sent successfully!!!");
         }else{
             JOptionPane.showMessageDialog(null, "Request Already Sent!!");
          }
         }
    }//GEN-LAST:event_sendBtnActionPerformed

    private void assignToMeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignToMeBtnActionPerformed
        // TODO add your handling code here:
         int selectedRow=Table2.getSelectedRow();
        if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
     return;
         }
        else
        {
            
            
            FundWorkRequest req=(FundWorkRequest)Table2.getValueAt(selectedRow,2);
            if(req.getReceiver()==null && req.getMessage().equalsIgnoreCase("Health")){
            req.setReceiver(account);
            req.setStatus("Processing");
            populateTable3();
            }
            else{
                JOptionPane.showMessageDialog(null, "Cannot Process The request Twice!!");
            }
            
            
        }
    }//GEN-LAST:event_assignToMeBtnActionPerformed

    private void completeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeBtnActionPerformed
        // TODO add your handling code here:
         int selectedRow= Table2.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
         else{
             
             FundWorkRequest f=(FundWorkRequest)Table2.getValueAt(selectedRow, 2);
             if(f.getReceiver()!=null)
                 if(f.getStatus().equalsIgnoreCase("Processing")){
                     UserAccount a = f.getSender();
                     f.setStatus("Complete");
                                        
               
                
                
                     JOptionPane.showMessageDialog(null, "You have successfully completed the Request!!!");
                     
                     populateTable3();
                     
                     
                     
                     ServiceReportWorkRequest report = new ServiceReportWorkRequest();
                     report.setStatus("Congrats");
                     report.setMessage("The Service has been provided to the Person");
                     report.setSender(account);
                     report.setReqId(f.getReqId());
                     report.setReqEmp(f.getReqEmp());
                     report.setReqName(f.getReqName());
                     
                     organization.getFundWorkQueue().getWorkRequestList().add(report);
                     account.getFundWorkQueue().getWorkRequestList().add(report);
                     system.getFundWorkQueue().getWorkRequestList().add(report);
                     
                 }
                     else{
                     JOptionPane.showMessageDialog(null, "Cannot Complete the Request Twice!!!");
                             
                             }
                     
             
         }
    }//GEN-LAST:event_completeBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Table;
    private javax.swing.JTable Table1;
    private javax.swing.JTable Table2;
    private javax.swing.JButton assignToMeBtn;
    private javax.swing.JButton calculateBtn;
    private javax.swing.JButton completeBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton sendBtn;
    // End of variables declaration//GEN-END:variables
}
