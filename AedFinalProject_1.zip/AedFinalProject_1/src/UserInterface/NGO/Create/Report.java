/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.NGO.Create;

import Business.EcoSystem;
import Business.EducationDetails.Details;
import Business.Enterprise.Enterprise;
import Business.General.General;
import Business.HealthDetails.HDetails;
import Business.Organization.NgoCreateOrganization;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.UserAccount.UserAccount;
import java.awt.CardLayout;
import javax.swing.JPanel;

/**
 *
 * @author shwet
 */
public class Report extends javax.swing.JPanel {

    /**
     * Creates new form Report
     */
    
    JPanel userProcessContainer;
    Enterprise enterprise;
    UserAccount account;
    EcoSystem system;
    NgoCreateOrganization organization;
    public Report(JPanel userProcessContainer, Enterprise enterprise, UserAccount account,NgoCreateOrganization organization, EcoSystem system) {
        initComponents();
        this.userProcessContainer=userProcessContainer;
        this.enterprise=enterprise;
        this.account=account;
        this.organization=organization;
        this.system=system;
        
        
        
        
        
        
        
        
        
        
        for(Organization org: enterprise.getOrganizationDirectory().getOrganizationList())
            if(org.toString().equalsIgnoreCase("General Department"))
             for(Person p:org.getPersonDirectory().getPersonList())
                 for(General d:p.getGeneralDirectory().getGeneralDirectory())
                      for(HDetails d1:p.gethDetailsDirectory().getHdetailsDirectory())
                          for(Details d2:p.getDetailsDirectory().getDetailsDirectory())
             {
               
               
             
               int countDrug=0;
               int countSexual=0;
               int countStress=0;
               int countDepression=0;
               int countSuicide=0;
               int countNormal=0;
               int countHeart=0;
               int countCancer=0;
               int countRespiratory=0;
               int countAccident=0;
               int countGastro=0;
               int countTotalPeople=0;
               int countTotalHealth=0;
               int countTotalEdu=0;
               int countTotalRehabAbuse=0;
               int countTotalGeneralProb=0;
               int countSchoolYes=0;
               int countSchoolNo=0;
               int countPrimary=0;
               int countSecondary=0;
               int countHigherSecondary=0;
               int countUnderGrad=0;
               int countGrad=0;
               int countNone=0;
               int countTotalSchool=0;
               int maxEducation=0;
               int maxHealth=0;
               int maxGeneral=0;
               String maxEducationName="";
               String maxHealthName="";
               String maxGeneralName="";
               
               
               countTotalPeople=org.getPersonDirectory().getPersonList().size();
               totalPeople.setText(Integer.toString(countTotalPeople));
               
               if(d.getDrugTaken().equalsIgnoreCase("Yes"))
               {
                   countDrug=countDrug+1;
               }
               else  if(d.getSexualAssault().equalsIgnoreCase("Yes"))
               {
                   countSexual=countSexual+1;
               }
               else  if(d.getDepression().equalsIgnoreCase("yes"))
               {
                   countDepression=countDepression+1;
               }
               else  if(d.getSuicide().equalsIgnoreCase("yes"))
               {
                   countSuicide=countSuicide+1;
               }
               else  if(d.getStress().equalsIgnoreCase("Yes"))
               {
                   countStress=countStress+1;
               }
               
                                  
               countTotalRehabAbuse=countDrug+countSexual;
               countTotalGeneralProb=countStress+countSuicide+countDepression;
               
               totalAbuse.setText(Integer.toString(countTotalRehabAbuse));
               totalGeneral.setText(Integer.toString(countTotalGeneralProb));
               
               if(countDrug>countSexual){
                   if(countDrug>countDepression)
                       if(countDrug>countSuicide)
                           if(countDrug>countStress)
                                   maxGeneralName="Drug Abuse";
                                   maxGeneral=countDrug;
               }
               else
                 if(countSexual>countDepression){
                       if(countSexual>countSuicide)
                           if(countSexual>countStress)
                                maxGeneralName="Sexual Abuse";                 
                              maxGeneral=countSexual;
                 }
               else
                     if(countDepression>countSuicide){
                           if(countDepression>countStress)
                               maxGeneralName="Depression";                  
                              maxGeneral=countDepression;
                     }
               else
                         if(countSuicide>countStress)
                         {                  
                              maxGeneral=countSuicide;
                              maxGeneralName="Suicide";
                         }
                         else{
                              maxGeneral=countStress;
                              maxGeneralName="Stress";
                         }
               
               maxRehabTxt.setText(maxGeneralName);
               commonRehab.setText(Integer.toString(maxGeneral));
               
               
               if(d1.getSevereReason().equalsIgnoreCase("Normal Illness"))
               {
                   countNormal=countNormal+1;
               }
               else  if(d1.getSevereReason().equalsIgnoreCase("Heart"))
               {
                   countHeart=countHeart+1;
               }
               else  if(d1.getSevereReason().equalsIgnoreCase("Respiratory Illness"))
               {
                   countRespiratory=countRespiratory+1;
               }
               else  if(d1.getSevereReason().equalsIgnoreCase("Accident"))
               {
                   countAccident=countAccident+1;
               }
               else  if(d1.getSevereReason().equalsIgnoreCase("Cancer"))
               {
                   countCancer=countCancer+1;
               }
               else  if(d1.getSevereReason().equalsIgnoreCase("Gastro Intestinal illness"))
               {
                   countGastro=countGastro+1;
               }               
               
               countTotalHealth=countHeart+countRespiratory+countAccident+countCancer+countGastro;
               totalHealth.setText(Integer.toString(countTotalHealth));
               
                if(countHeart>countRespiratory){
                   if(countHeart>countAccident)
                       if(countHeart>countCancer)
                           if(countHeart>countGastro)
                               maxHealthName="Heart";
                                   maxHealth=countHeart;
               }
               else
                 if(countRespiratory>countAccident){
                       if(countRespiratory>countCancer)
                           if(countRespiratory>countGastro)
                                maxHealthName="Respiratory";                 
                              maxHealth=countRespiratory;
                 }
               else
                     if(countAccident>countCancer){
                           if(countAccident>countGastro)
                                 maxHealthName="Accident";                
                              maxHealth=countAccident;
                     }
               else
                         if(countCancer>countGastro)
                         {                 
                              maxHealth=countCancer;
                              maxHealthName="Cancer";
                         }
                         else{
                              maxHealth=countGastro;
                              maxHealthName="Gastro";
                         }
                         
                
                commonDiease.setText(maxHealthName);
                maxHealthTxt.setText(Integer.toString(maxHealth));
                
               
                         
             
               
               
               
               if(d2.getSchool().equalsIgnoreCase("Yes"))
               {
                   countSchoolYes=countSchoolYes+1;
               }
               else
               {
                   countSchoolNo=countSchoolNo+1;
               }
               
               
               countTotalSchool=countSchoolYes;
               totalEdu.setText(Integer.toString(countTotalSchool));
               
                if(d2.getQualification().equalsIgnoreCase("Primary"))
               {
                   countPrimary=countPrimary+1;
               }
               else  if(d2.getQualification().equalsIgnoreCase("Secondary"))
               {
                   countSecondary=countSecondary+1;
               }
               else  if(d2.getQualification().equalsIgnoreCase("Higher Secondary"))
               {
                   countHigherSecondary=countHigherSecondary+1;
               }
               else  if(d2.getQualification().equalsIgnoreCase("Under Graduate"))
               {
                   countUnderGrad=countUnderGrad+1;
               }
               else  if(d2.getQualification().equalsIgnoreCase("Graduate"))
               {
                   countGrad=countGrad+1;
               }
               else if(d2.getQualification().equalsIgnoreCase("None"))
               {
                   countNone=countNone+1;
               }
               
               if(countPrimary>countSecondary){
                   if(countPrimary>countHigherSecondary)
                       if(countPrimary>countUnderGrad)
                           if(countPrimary>countGrad)
                               if(countPrimary>countNone)
                                   maxEducation=countPrimary;
                   maxEducationName="Primary";
               }
               else
                 if(countSecondary>countHigherSecondary){
                       if(countSecondary>countUnderGrad)
                           if(countSecondary>countGrad)
                               if(countSecondary>countNone)                  
                              maxEducation=countSecondary;
                        maxEducationName="Secondary";
                 }
               else
                     if(countHigherSecondary>countUnderGrad){
                           if(countHigherSecondary>countGrad)
                               if(countHigherSecondary>countNone)                  
                              maxEducation=countHigherSecondary;
                            maxEducationName="HigherSecondary";
                     }
               else
                         if(countUnderGrad>countGrad){
                               if(countUnderGrad>countNone)                  
                              maxEducation=countUnderGrad;
                                maxEducationName="UnderGraduate";
                         }
               else
                      if(countUnderGrad>countNone)   {               
                              maxEducation=countGrad;
                       maxEducationName="Graduate";
                      }
               else
                      {
                          maxEducation=countNone;
                           maxEducationName="None";
                      }
               
               commonEdu.setText(maxEducationName);
                maxEduTxt.setText(Integer.toString(maxEducation));
                         
             }
        
        
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        totalPeople = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        totalHealth = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        commonDiease = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        maxHealthTxt = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        totalEdu = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        commonEdu = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        maxEduTxt = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        totalAbuse = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        totalGeneral = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        maxRehabTxt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        commonRehab = new javax.swing.JTextField();
        backButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("TOTAL NO PEOPLE SURVEYED:");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 148, -1, 36));
        add(totalPeople, new org.netbeans.lib.awtextra.AbsoluteConstraints(729, 148, 423, 36));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "HEALTH"), "HEALTH"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("TOTAL PEOPLE WITH HEALTH PROBLEMS:");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 43, -1, -1));
        jPanel1.add(totalHealth, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 40, 294, -1));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("COMMON DIEASE:");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 94, 320, -1));
        jPanel1.add(commonDiease, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 91, 294, -1));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("COUNT OF COMMON DIEASE:");
        jLabel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 138, 320, -1));
        jPanel1.add(maxHealthTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 135, 294, -1));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 708, 210));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "EDUCATION"));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("TOTAL PEOPLE WITH EDUCATION PROBLEMS:");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("COMMON EDUCATION LEVEL:");
        jLabel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("COUNT OF COMMON EDUCATION:");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(commonEdu, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
                    .addComponent(totalEdu)
                    .addComponent(maxEduTxt)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(totalEdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(commonEdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(maxEduTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 440, -1, -1));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "GENERAL ABUSE AND REHAB"));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("TOTAL ABUSE PROBLEMS:");
        jLabel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 41, 270, -1));

        totalAbuse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalAbuseActionPerformed(evt);
            }
        });
        jPanel3.add(totalAbuse, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 38, 294, -1));

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("TOTAL GENERAL PROBLEM:");
        jLabel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 90, 270, -1));
        jPanel3.add(totalGeneral, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 89, 294, -1));

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("COMMON PROBLEM:");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 136, 270, -1));
        jPanel3.add(maxRehabTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 133, 294, -1));

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("COUNT OF COMMON PROBLEM:");
        jLabel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 186, 270, -1));

        commonRehab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                commonRehabActionPerformed(evt);
            }
        });
        jPanel3.add(commonRehab, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 183, 294, -1));

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 200, 620, 225));

        backButton.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        backButton.setText("<<BACK");
        backButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        backButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        add(backButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 670, 157, 48));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REPORT TO GOVERMENT");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1630, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(106, 106, 106))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 16, 1864, -1));
        add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 490, 50, 20));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/I-CARE.jpg"))); // NOI18N
        add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 280, 480, 420));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/NGO/Create/REPORT.png"))); // NOI18N
        add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 450, 140, 160));
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
         userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
        
    }//GEN-LAST:event_backButtonActionPerformed

    private void totalAbuseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalAbuseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalAbuseActionPerformed

    private void commonRehabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_commonRehabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_commonRehabActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JTextField commonDiease;
    private javax.swing.JTextField commonEdu;
    private javax.swing.JTextField commonRehab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTextField maxEduTxt;
    private javax.swing.JTextField maxHealthTxt;
    private javax.swing.JTextField maxRehabTxt;
    private javax.swing.JTextField totalAbuse;
    private javax.swing.JTextField totalEdu;
    private javax.swing.JTextField totalGeneral;
    private javax.swing.JTextField totalHealth;
    private javax.swing.JTextField totalPeople;
    // End of variables declaration//GEN-END:variables
}
