/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.NGO.General;

import Business.EcoSystem;
import Business.Employee.Employee;
import Business.Enterprise.Enterprise;
import Business.EventInfo.EventInfo;
import Business.EventWorkQueue.EventWorkRequest;
import Business.FundWorkQueue.FundWorkRequest;
import Business.FundWorkQueue.ReportFundWorkRequest;
import Business.FundWorkQueue.ServiceReportWorkRequest;
import Business.Organization.NgoGeneralOrganization;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.SocialIssues.SocialIssues;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkRequest;
import UserInterface.MainJFrame;
import com.teknikindustries.bulksms.SMS;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import static java.lang.Thread.sleep;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author shwet
 */
public class NgoGeneralAdminWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form NgoGeneralAdminWorkArea
     */
    JPanel userProcessContainer;
    EcoSystem system;
    NgoGeneralOrganization organization;
    UserAccount account;
    Enterprise enterprise;
    public NgoGeneralAdminWorkArea(JPanel userProcessContainer, EcoSystem system, UserAccount account,Enterprise enterprise,NgoGeneralOrganization organization) {
        initComponents();
         this.userProcessContainer = userProcessContainer;
        this.system = system;
        this.account=account;
        this.enterprise=enterprise;
        this.organization=organization;
       
        populateTable();
        populateTable2();
        populateTable3();
        for(FundWorkRequest req:system.getFundWorkQueue().getWorkRequestList())
        if(req instanceof ReportFundWorkRequest){
        populateTable6();
        }
        else if (req instanceof ServiceReportWorkRequest)
        {
            populateTable7();
        }
         
         CurrentNews.setEnabled(false);
         
         for(Organization org:enterprise.getOrganizationDirectory().getOrganizationList())
             if(org.toString().equalsIgnoreCase("create"))
       if(org.getSocialIssuesDirectory().getSocialIssuesDirectory().size()>0)
            {
                CurrentNews.setEnabled(true);
                JOptionPane.showMessageDialog(null, "Breaking News!!!!!");
            }
        
        
        int sum=0;
        for(Person p: organization.getPersonDirectory().getPersonList())
            for(Employee e : organization.getEmployeeDirectory().getEmployeeList())
             if(organization.toString().equalsIgnoreCase("General Department") && p.getEmpName().equalsIgnoreCase(e.getName()) && account.getEmployee().getName().equalsIgnoreCase(e.getName()) )
        {
            sum =sum+1;
            
        }
        peopleTxt.setText(Integer.toString(sum));
    }
public void populateTable(){
        DefaultTableModel model = (DefaultTableModel)Table.getModel();
        
        model.setRowCount(0);
        
        for(EventWorkRequest request : organization.getEventWorkQueue().getWorkRequestList())
          if(request.getCategory().equalsIgnoreCase(account.getRole().toString()))
              if(request.getReceiver().size()<request.getVol())
          {  
            Object[] row = new Object[4];
            row[0] = request;
            row[1] = request.getSender().getEmployee().getName();
            row[2] = request.getReceiver() == null ? null : request.getReceiver();
            row[3] = request.getStatus();
            
            model.addRow(row);
         }
        
    }
public void populateTable2(){
    DefaultTableModel model = (DefaultTableModel)Table2.getModel();
        
        model.setRowCount(0);
        
           
        for(EventWorkRequest request : organization.getEventWorkQueue().getWorkRequestList()){
            if(request.getStatus().equalsIgnoreCase("Complete")  )
                for(UserAccount a:request.getReceiver())
                    if(a.getEmployee().getName().equalsIgnoreCase(account.toString()))
                for(Organization org: enterprise.getOrganizationDirectory().getOrganizationList())
                 if(org.toString().equalsIgnoreCase("Create"))
                for(EventInfo e:org.getEventInfoDirectory().getEventInfoDirectory()){
                    if(e.getCategory().equalsIgnoreCase(account.getRole().toString()) ){
                       Object[] row = new Object[6];
                       row[0] =e;
                       row[1] =e.getAudience();
                       row[2] = e.getDate();
                       row[3] = e.getDescription();
                       row[4] = e.getLocation();
                       
                       model.addRow(row);
                    }
                }
        }
        
}
public void populateTable3()
{
     DefaultTableModel model = (DefaultTableModel)Table3.getModel();        
     model.setRowCount(0);
        
     for(Person p : organization.getPersonDirectory().getPersonList())  
         for(Employee e : organization.getEmployeeDirectory().getEmployeeList())
             
  if(organization.toString().equalsIgnoreCase("General Department") && p.getEmpName().equalsIgnoreCase(e.getName()) && account.getEmployee().getName().equalsIgnoreCase(e.getName()) )
  
  
  {
         Object row[] = new Object[7];
         row[0] = p.getId();
         row[1] = p.getFirstName()+" "+p.getLastName();
         row[2] = p.getGender();
         row[3] = e.getName();
         
         
         model.addRow(row);
     }
}
public void populateTable4(){
        DefaultTableModel model = (DefaultTableModel)Table.getModel();
        
        model.setRowCount(0);
        
        for(EventWorkRequest request : organization.getEventWorkQueue().getWorkRequestList())
          if(request.getStatus().equalsIgnoreCase("Pending") && request.getReceiver().contains(account))
             
          {  
            Object[] row = new Object[4];
            row[0] = request;
            row[1] = request.getSender().getEmployee().getName();
            row[2] = request.getReceiver() == null ? null : request.getReceiver();
            row[3] = request.getStatus();
            
            model.addRow(row);
         }
        
    }
public void populateTable5(){
        DefaultTableModel model = (DefaultTableModel)Table.getModel();
        
        model.setRowCount(0);
        
        for(EventWorkRequest request : organization.getEventWorkQueue().getWorkRequestList())
          if(request.getStatus().equalsIgnoreCase("Complete") && request.getReceiver().contains(account))
             
          {  
            Object[] row = new Object[4];
            row[0] = request;
            row[1] = request.getSender().getEmployee().getName();
            row[2] = request.getReceiver() == null ? null : request.getReceiver();
            row[3] = request.getStatus();
            
            model.addRow(row);
         }
        
    }

public void populateTable6()
{
     DefaultTableModel model = (DefaultTableModel)Table4.getModel();        
     model.setRowCount(0);
     for(Person p : organization.getPersonDirectory().getPersonList()) 
      for(FundWorkRequest req:system.getFundWorkQueue().getWorkRequestList())
       if(req instanceof ReportFundWorkRequest)
       if(req.getMessage().equalsIgnoreCase("The Fund has been granted and forwarded the request to services.") && req.getReqId().equalsIgnoreCase(p.getReqId()) && req.getReqName().equalsIgnoreCase(p.getReqName()) && req.getReqEmp().equalsIgnoreCase(account.getEmployee().getName())){  
      
         for(Employee e : organization.getEmployeeDirectory().getEmployeeList())
             
  if(organization.toString().equalsIgnoreCase("General Department") && p.getEmpName().equalsIgnoreCase(e.getName()) && account.getEmployee().getName().equalsIgnoreCase(e.getName()) )
   
  
  {
         Object row[] = new Object[7];
         row[0] = p.getId();
         row[1] = p.getFirstName()+" "+p.getLastName();
         row[2] = p.getPhoneNumber();
         row[3] = e.getName();
         row[4]= ((ReportFundWorkRequest)req);
         
         model.addRow(row);
     }
       }
}

public void populateTable7()
{
     DefaultTableModel model = (DefaultTableModel)Table4.getModel();        
     model.setRowCount(0);
     for(Person p : organization.getPersonDirectory().getPersonList()) 
      for(FundWorkRequest req:system.getFundWorkQueue().getWorkRequestList())
       if(req instanceof ServiceReportWorkRequest)
       if(req.getMessage().equalsIgnoreCase("The service has been provided to the person") && req.getReqId().equalsIgnoreCase(p.getReqId()) && req.getReqName().equalsIgnoreCase(p.getReqName()) && req.getReqEmp().equalsIgnoreCase(account.getEmployee().getName())){  
      
         for(Employee e : organization.getEmployeeDirectory().getEmployeeList())
             
  if(organization.toString().equalsIgnoreCase("General Department") && p.getEmpName().equalsIgnoreCase(e.getName()) && account.getEmployee().getName().equalsIgnoreCase(e.getName()) )
   
  
  {
         Object row[] = new Object[7];
         row[0] = p.getId();
         row[1] = p.getFirstName()+" "+p.getLastName();
         row[2] = p.getPhoneNumber();
         row[3] = e.getName();
         row[4]= ((ServiceReportWorkRequest)req);
         
         model.addRow(row);
     }
       }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        peopleTxt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        Table3 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Table2 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        completebtn = new javax.swing.JButton();
        assignbtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        popPanel = new javax.swing.JPanel();
        navigateBtn = new javax.swing.JButton();
        CurrentNews = new javax.swing.JButton();
        nextbtn = new javax.swing.JButton();
        backbtn = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Table4 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        number = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        message = new javax.swing.JTextField();
        send = new javax.swing.JButton();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "LIST OF PEOPLE"));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Total No Of People Interviewed::");
        jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        peopleTxt.setEditable(false);
        peopleTxt.setEnabled(false);
        peopleTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                peopleTxtActionPerformed(evt);
            }
        });

        Table3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Table3.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N
        Table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Name", "Gender", "VolunteerName", "Status"
            }
        ));
        jScrollPane3.setViewportView(Table3);
        if (Table3.getColumnModel().getColumnCount() > 0) {
            Table3.getColumnModel().getColumn(0).setResizable(false);
            Table3.getColumnModel().getColumn(1).setResizable(false);
            Table3.getColumnModel().getColumn(2).setResizable(false);
            Table3.getColumnModel().getColumn(3).setResizable(false);
            Table3.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(peopleTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(peopleTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 390, 760, 240));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "EVENTS SCHEDULE"));

        Table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "EventId", "Targeted Audience", "Event Date", "Description", "Location"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(Table2);
        if (Table2.getColumnModel().getColumnCount() > 0) {
            Table2.getColumnModel().getColumn(0).setResizable(false);
            Table2.getColumnModel().getColumn(1).setResizable(false);
            Table2.getColumnModel().getColumn(2).setResizable(false);
            Table2.getColumnModel().getColumn(3).setResizable(false);
            Table2.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 688, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 140, 760, 240));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "EVENT WORK REQUEST TABLE"));

        Table.setFont(new java.awt.Font("Times New Roman", 2, 16)); // NOI18N
        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Message", "Sender", "reciever", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Table);
        if (Table.getColumnModel().getColumnCount() > 0) {
            Table.getColumnModel().getColumn(0).setResizable(false);
            Table.getColumnModel().getColumn(1).setResizable(false);
            Table.getColumnModel().getColumn(2).setResizable(false);
            Table.getColumnModel().getColumn(3).setResizable(false);
        }

        completebtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        completebtn.setText("COMPLETE");
        completebtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        completebtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        completebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completebtnActionPerformed(evt);
            }
        });

        assignbtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        assignbtn.setText("ASSIGN TO ME");
        assignbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        assignbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(assignbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(completebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(92, 92, 92))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(completebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 820, 250));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("NGO VOLUNTEER WORK AREA");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/NGO/General/VOL.png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1552, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 1880, 130));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/NGO/General/volunteering-hand-volunteer-participation-256.png"))); // NOI18N
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1710, 220, 230, 250));

        popPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        navigateBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        navigateBtn.setText("NAVIGATE");
        navigateBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        navigateBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        navigateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navigateBtnActionPerformed(evt);
            }
        });

        CurrentNews.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        CurrentNews.setText("CURRENT NEWS");
        CurrentNews.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        CurrentNews.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CurrentNews.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CurrentNewsActionPerformed(evt);
            }
        });

        nextbtn.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        nextbtn.setText("NEXT>>");
        nextbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        nextbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        nextbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextbtnActionPerformed(evt);
            }
        });

        backbtn.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        backbtn.setText("<<BACK");
        backbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        backbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout popPanelLayout = new javax.swing.GroupLayout(popPanel);
        popPanel.setLayout(popPanelLayout);
        popPanelLayout.setHorizontalGroup(
            popPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(popPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(321, 321, 321)
                .addComponent(navigateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(234, 234, 234)
                .addComponent(CurrentNews, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 396, Short.MAX_VALUE)
                .addComponent(nextbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );
        popPanelLayout.setVerticalGroup(
            popPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(popPanelLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(popPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(navigateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CurrentNews, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nextbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(popPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 660, 1630, 60));

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "REQUEST STATUS"));

        Table4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Table4.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N
        Table4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Name", "Mobile Number", "VolunteerName", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(Table4);
        if (Table4.getColumnModel().getColumnCount() > 0) {
            Table4.getColumnModel().getColumn(0).setResizable(false);
            Table4.getColumnModel().getColumn(1).setResizable(false);
            Table4.getColumnModel().getColumn(2).setResizable(false);
            Table4.getColumnModel().getColumn(3).setResizable(false);
            Table4.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel3.setText("NUMBER");

        number.setText("+1");

        jLabel7.setText("MESSAGE");

        send.setFont(new java.awt.Font("Times New Roman", 3, 16)); // NOI18N
        send.setText("SEND");
        send.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        send.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel7))
                                .addGap(21, 21, 21)
                                .addComponent(number, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addComponent(send, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(28, 28, 28)
                        .addComponent(send))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, 870, 230));
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backbtnActionPerformed

    private void nextbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextbtnActionPerformed
        // TODO add your handling code here:
        PersonalDetailsJPanel manageEnterpriseAdminJPanel = new PersonalDetailsJPanel(userProcessContainer,account,organization,enterprise,system);
        userProcessContainer.add("SynchronizerJPanel", manageEnterpriseAdminJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer); 
    }//GEN-LAST:event_nextbtnActionPerformed

    private void assignbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignbtnActionPerformed
        // TODO add your handling code here:
         int selectedRow= Table.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
     return;
         }
         
        EventWorkRequest request = (EventWorkRequest)Table.getValueAt(selectedRow, 0);
        int count=request.getVol();
        
        if(count>0){          
       ArrayList<UserAccount> temp = new ArrayList<>();   
       temp.add(account);
        request.setReceiver(temp);
        request.setStatus("Pending");
        count--;
        int count1=count;
        request.setVol(count1);
        populateTable4();
         }else{
             JOptionPane.showMessageDialog(null, "The required number of volunteers have already registered!!!!");
         }
    }//GEN-LAST:event_assignbtnActionPerformed

    private void completebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completebtnActionPerformed
        // TODO add your handling code here:
         int selectedRow= Table.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }else{
         EventWorkRequest s=(EventWorkRequest)Table.getValueAt(selectedRow, 0);
         if(s.getReceiver()!= null){
         if (s.getStatus().equals("Pending")) {
         UserAccount a =s.getSender();
         s.setStatus("Complete");
         
          JOptionPane.showMessageDialog(null, "You have successfully completed the request");
          populateTable5();
          populateTable2();
         }
             }
         }
    }//GEN-LAST:event_completebtnActionPerformed

    private void peopleTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_peopleTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_peopleTxtActionPerformed

    private void sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendActionPerformed
        // TODO add your handling code here:
        int selectedRow=Table4.getSelectedRow();
        if(selectedRow<0)
        {
            JOptionPane.showMessageDialog(null, "Please select a row!!!");
        }
        else{
            FundWorkRequest req=(FundWorkRequest)Table4.getValueAt(selectedRow,4);
            
            
        SMS send = new SMS();
        send.SendSMS("ayush94", "Ayushjain94", message.getText(),number.getText(), "http://usa.bulksms.com/eapi/submission/send_sms/2/2.0");
        JOptionPane.showMessageDialog(null, "Message Sent SuccessFully!!");
        }
    }//GEN-LAST:event_sendActionPerformed

    private void navigateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navigateBtnActionPerformed
        // TODO add your handling code here:
        Browser browser = new Browser();
        BrowserView view = new BrowserView(browser);

        JFrame frame = new JFrame("JxBrowser Google Maps");
       
        frame.add(view, BorderLayout.CENTER);
        frame.setSize(700, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        browser.loadURL("http://maps.google.com");
    }//GEN-LAST:event_navigateBtnActionPerformed

    private void CurrentNewsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CurrentNewsActionPerformed
        // TODO add your handling code here:
        SocialIssuesJPanel manageOrganizationJPanel = new SocialIssuesJPanel(userProcessContainer, enterprise.getOrganizationDirectory());
        userProcessContainer.add("SocialIssuesJPanel", manageOrganizationJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_CurrentNewsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CurrentNews;
    private javax.swing.JTable Table;
    private javax.swing.JTable Table2;
    private javax.swing.JTable Table3;
    private javax.swing.JTable Table4;
    private javax.swing.JButton assignbtn;
    private javax.swing.JButton backbtn;
    private javax.swing.JButton completebtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField message;
    private javax.swing.JButton navigateBtn;
    private javax.swing.JButton nextbtn;
    private javax.swing.JTextField number;
    private javax.swing.JTextField peopleTxt;
    private javax.swing.JPanel popPanel;
    private javax.swing.JButton send;
    // End of variables declaration//GEN-END:variables
}
