/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.NGO.Task;

import Business.Donation.DonationDetails;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.InvWorkQueue.InvWorkRequest;
import Business.InvWorkQueue.InvWorkWorkRequest;
import Business.NGOInventory.NGOInventory;
import Business.Organization.NgoTaskOrganization;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.UserAccount.UserAccount;
import Business.UtilitiesRequirements.UtilitiesDetails;
import Business.UtilityWorkQueue.UtilityWorkRequest;
import Business.UtilityWorkQueue.UtilityWorkWorkRequest;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author maila
 */
public class InventoryRequest extends javax.swing.JPanel {

    /**
     * Creates new form InventoryRequest
     */
    JPanel userProcessContainer;
    EcoSystem system;    
    NgoTaskOrganization organization;
    UserAccount account;
    Enterprise enterprise;
    public InventoryRequest(JPanel userProcessContainer ,NgoTaskOrganization organization,EcoSystem system,UserAccount account, Enterprise enterprise) {
        initComponents();
         this.userProcessContainer = userProcessContainer;
        this.system = system;
        this.account=account;        
        this.organization=organization;
        this.enterprise=enterprise;
        
        populateAvail1();
        populateAvail2();
        populateReq1();
        populateReq2();
        
    }




public void populateAvail1()
{
    DefaultTableModel dtm = (DefaultTableModel)avail1.getModel();
        dtm.setRowCount(0);
        
        for(Organization org:enterprise.getOrganizationDirectory().getOrganizationList())
            if( org.toString().equalsIgnoreCase("General Department")){
        for(DonationDetails dd: org.getDonationDetailsDirectory().getDonationDetailsList())
        {
          
           
            Object[] row=new Object[8];
            row[0]=dd.getWoollensQty();
            row[1]=dd.getBlanketsQty();
            row[2]=dd.getSnowBootsQty();
            row[3]=dd.getStationaryQty();
            row[4]=dd.getUmbrellasQty();
            row[5]=dd.getClothesQty();
            row[6]=dd.getGroceryQty();
            dtm.addRow(row);
            
        }
            }
            
           
        
}
 
  public void populateAvail2()
    {
        DefaultTableModel dtm = (DefaultTableModel)avail2.getModel();
        dtm.setRowCount(0);
        
        
        
       for(NGOInventory ni:organization.getNgoInventoryDirectory().getNgoInventoryDirectory()){
            
            Object[] row = new Object[6];
            row[0]= ni.getPen();
            row[1]= ni.getPaper();
            row[2]= ni.getPencil();
            row[3]= ni.getChairs();
            row[4]= ni.getTable();
            row[5]= ni.getCloth();
            
            dtm.addRow(row);
            
            //break;
       }
            
            
    }
  
  public void populateReq1()
    {
        DefaultTableModel dtm = (DefaultTableModel)req1.getModel();
        dtm.setRowCount(0);
        
           
        for(UtilityWorkRequest req: organization.getUtilityWorkQueue().getWorkRequestList())
        {
            
                
            Object[] row = new Object[10];
            row[0]=((UtilityWorkWorkRequest) req).getWoolrequestQuantity();
            row[1]=((UtilityWorkWorkRequest) req).getBlanketrequestQuantity();
            row[2]=((UtilityWorkWorkRequest) req).getSnowBootsrequestQuantity();
            row[3]=((UtilityWorkWorkRequest) req).getStationeryrequestQuantity();
            row[4]=((UtilityWorkWorkRequest) req).getUmbrellarequestQuantity();
            row[5]=((UtilityWorkWorkRequest) req).getClothesrequestQuantity();
            row[6]=((UtilityWorkWorkRequest) req).getGroceryrequestQuantity();
            row[7]=req.getSender();
            row[8]=req.getReceiver();
            row[9]=req;
            
            dtm.addRow(row);
        
        
            }
    }
 
  public void populateReq2()
    {
        DefaultTableModel dtm = (DefaultTableModel)req2.getModel();
        dtm.setRowCount(0);
        
        for(InvWorkRequest req: organization.getInvWorkQueue().getWorkRequestList())
        {
            Object[] row = new Object[10];
            row[0]=((InvWorkWorkRequest) req).getPenrequestQuantity();
            row[1]=((InvWorkWorkRequest) req).getPaperrequestQuantity();
            row[2]=((InvWorkWorkRequest) req).getPencilrequestQuantity();
            row[3]=((InvWorkWorkRequest) req).getChairsrequestQuantity();
            row[4]=((InvWorkWorkRequest) req).getTablerequestQuantity();
            row[5]=((InvWorkWorkRequest) req).getClothrequestQuantity();
            row[6]=req.getSender();
            row[7]=req.getReceiver();
            row[8]=req;
                    
            dtm.addRow(row);
        }
            
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        avail1 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        avail2 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        req1 = new javax.swing.JTable();
        completeuti = new javax.swing.JButton();
        assignUti = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        req2 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("AVAILABLE INVENTORY");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/NGO/Task/INVENTORY.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jLabel2)
                .addGap(36, 36, 36)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1431, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 1810, 120));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "AVAILABLE INVENTORY"));

        avail1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Wollens", "Blankets", "Snow Boots", "Stationery", "Umbrellas", "Clothes", "Grocery"
            }
        ));
        jScrollPane1.setViewportView(avail1);

        avail2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pen", "Paper", "Pencil", "Chairs", "Table", "Cloth"
            }
        ));
        jScrollPane4.setViewportView(avail2);

        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jButton4.setText("ADD>>");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(200, 200, 200))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 558, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 600, 472));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "INVENTORY REQUEST FOR UTILITY"));

        req1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Wollens", "Blankets", "Snow Boots", "Stationery", "Umbrellas", "Clothes", "Grocery", "Sender", "Reciever", "Status"
            }
        ));
        jScrollPane5.setViewportView(req1);

        completeuti.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        completeuti.setText("COMPLETE");
        completeuti.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        completeuti.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        completeuti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeutiActionPerformed(evt);
            }
        });

        assignUti.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        assignUti.setText("ASSIGN TO ME");
        assignUti.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignUti.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        assignUti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignUtiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 988, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(assignUti, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(completeuti, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignUti, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(completeuti, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, 1000, -1));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "INVENTORY REQUEST FOR EVENTS"));

        req2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Pen", "Paper", "Pencil", "Chairs", "Table", "Cloth", "Sender", "reciever", "Status"
            }
        ));
        jScrollPane2.setViewportView(req2);

        jButton1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jButton1.setText("ASSIGN TO ME");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jButton2.setText("COMPLETE");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)))
                .addGap(69, 69, 69))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 510, -1, 290));

        jButton3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jButton3.setText("<<<<BACK");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 660, 134, 51));
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        AddMaterials manageOrganizationJPanel = new AddMaterials(userProcessContainer, organization,system,account,enterprise);
        userProcessContainer.add("AddMaterials", manageOrganizationJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer); 
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
           
           
         
                
            int selectedRow1= req2.getSelectedRow();
         if(selectedRow1<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
        else{
             
         InvWorkWorkRequest u=(InvWorkWorkRequest) req2.getValueAt(selectedRow1, 8);
         if(u.getStatus().equals("Sent")){
         u.setStatus("Pending");
         u.setReceiver(account);
         
         populateReq2();
}else{
    JOptionPane.showMessageDialog(null, "Already Done!");
}
         }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         

             
        
        
        int selectedRow= req2.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
        else{
             
         InvWorkWorkRequest i=(InvWorkWorkRequest) req2.getValueAt(selectedRow, 8);
           
        if(i.getReceiver()!= null){
         if (i.getStatus().equals("Pending")) {
         UserAccount a =i.getSender();
         int temp=0;
         if(organization.getNgoInventoryDirectory().getNgoInventoryDirectory().size()<= 0){
             JOptionPane.showMessageDialog(null, "No Stock available.");
            return;
         }
        for (NGOInventory v : organization.getNgoInventoryDirectory().getNgoInventoryDirectory()) {
      
            if(v.getChairs()- i.getChairsrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough Chairs");
            return;
            }
            else if(v.getCloth()- i.getClothrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough Cloth");
            return;
            }
            else if(v.getPaper()- i.getPaperrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough paper");
            return;
            }
            else if(v.getPen()- i.getPenrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough pen");
            return;
            }
            else if(v.getPencil()- i.getPencilrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough Pencil");
            return;
            }
            else if(v.getTable()- i.getTablerequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough Table");
            return;
            }
            
            v.setChairs(v.getChairs()-i.getChairsrequestQuantity());
            v.setCloth(v.getCloth()-i.getClothrequestQuantity());
            v.setPaper(v.getPaper()-i.getPaperrequestQuantity());
            v.setPen(v.getPen()-i.getPenrequestQuantity());
            v.setPencil(v.getPencil()-i.getPencilrequestQuantity());
            v.setTable(v.getTable()-i.getTablerequestQuantity());
            temp=1;
        
        
    }
        if(temp==0){
            JOptionPane.showMessageDialog(null, "No Stock available.");
        }
        else{
         i.setStatus("Complete");
          JOptionPane.showMessageDialog(null, "You have successfully completed the request");
          populateAvail2();
          populateReq2();
     } 
         }else {
                JOptionPane.showMessageDialog(null, "You cannot complete it two times.");
            }
        }
        else{
        JOptionPane.showMessageDialog(null, "Please assign first");
        }
        
         }

        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void assignUtiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignUtiActionPerformed
        // TODO add your handling code here:
        int selectedRow= req1.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
        else{
             
         UtilityWorkWorkRequest uq=(UtilityWorkWorkRequest) req1.getValueAt(selectedRow, 9);
         if(uq.getStatus().equalsIgnoreCase("Sent")){
         uq.setStatus("Pending");
         uq.setReceiver(account);
         
         populateReq1();
}else{
    JOptionPane.showMessageDialog(null, "Already Done!");
}
         }
        
    }//GEN-LAST:event_assignUtiActionPerformed

    private void completeutiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeutiActionPerformed
        // TODO add your handling code here:
        int selectedRow1= req1.getSelectedRow();
         if(selectedRow1<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
        else{
             
         UtilityWorkWorkRequest i=(UtilityWorkWorkRequest) req1.getValueAt(selectedRow1, 9);
           
        if(i.getReceiver()!= null){
         if (i.getStatus().equals("Pending")) {
         UserAccount a =i.getSender();
         int temp=0;
         for(Organization org:enterprise.getOrganizationDirectory().getOrganizationList())
             if(org.toString().equalsIgnoreCase("Health Department") )
        for (DonationDetails d : org.getDonationDetailsDirectory().getDonationDetailsList())
         if(org.getDonationDetailsDirectory().getDonationDetailsList().size()<= 0){
             JOptionPane.showMessageDialog(null, "No Stock available.");
            return;
         }
         for(Organization org:enterprise.getOrganizationDirectory().getOrganizationList())
             if(org.toString().equalsIgnoreCase("Health Department") )
        
        for(DonationDetails util:org.getDonationDetailsDirectory().getDonationDetailsList()){
                
            if(util.getBlanketsQty()- i.getBlanketrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for Blanket");
            return;
            }
            else if(util.getClothesQty()- i.getClothesrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for clothes");
            return;
            }
            else if(util.getGroceryQty()- i.getGroceryrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for Grocery");
            return;
            }
            else if(util.getSnowBootsQty()- i.getSnowBootsrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for snow Boots");
            return;
            }
            else if(util.getStationaryQty()- i.getStationeryrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for Stationery");
            return;
            }
            else if(util.getUmbrellasQty()- i.getUmbrellarequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for Umbrella");
            return;
            }
            else if(util.getWoollensQty()- i.getWoolrequestQuantity()<0){
                JOptionPane.showMessageDialog(null, "Not enough stock for Woollen");
            return;
            }
                     
            
            util.setBlanketsQty(util.getBlanketsQty()-i.getBlanketrequestQuantity());
            util.setClothesQty(util.getClothesQty()-i.getClothesrequestQuantity());
            util.setGroceryQty(util.getGroceryQty()-i.getGroceryrequestQuantity());
            util.setSnowBootsQty(util.getSnowBootsQty()-i.getSnowBootsrequestQuantity());
            util.setStationaryQty(util.getStationaryQty()-i.getStationeryrequestQuantity());
            util.setUmbrellasQty(util.getUmbrellasQty()-i.getUmbrellarequestQuantity());
            util.setWoollensQty(util.getWoollensQty()-i.getWoolrequestQuantity());
            
            temp=1;
        
        
    }
        if(temp==0){
            JOptionPane.showMessageDialog(null, "No Stock available.");
        }
        else{
         i.setStatus("Complete");
          JOptionPane.showMessageDialog(null, "You have successfully completed the request");
          
          populateAvail1();
          populateReq1();
        }
     } else {
                JOptionPane.showMessageDialog(null, "You cannot complete it two times.");
            }
        }
        else{
        JOptionPane.showMessageDialog(null, "Please assign first");
        }
        
         }
    }//GEN-LAST:event_completeutiActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton assignUti;
    private javax.swing.JTable avail1;
    private javax.swing.JTable avail2;
    private javax.swing.JButton completeuti;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable req1;
    private javax.swing.JTable req2;
    // End of variables declaration//GEN-END:variables
}
