/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.Funder.Health;

import UserInterface.Funder.Education.*;
import Business.EcoSystem;
import Business.EducationDetails.Details;
import Business.Enterprise.Enterprise;
import Business.FundWorkQueue.FundRequestWorkRequest;
import Business.FundWorkQueue.FundWorkRequest;
import Business.FundWorkQueue.FundWorkWorkRequest;
import Business.FundWorkQueue.HealthFundWorkRequest;
import Business.FundWorkQueue.QuotationAnsWorkRequest;
import Business.FundWorkQueue.ReportFundWorkRequest;
import Business.FundWorkQueue.ServiceRequestWorkrequest;
import Business.Network.Network;
import Business.Organization.EducationFunderOrganization;
import Business.Organization.HealthFunderOrganization;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkRequest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Rishika
 */
public class FunderHealthWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form FunderEducationWorkArea
     */
    JPanel userProcessContainer;
    EcoSystem system;
    HealthFunderOrganization organization;
    UserAccount account;
    Enterprise enterprise;
    public FunderHealthWorkArea(JPanel userProcessContainer, UserAccount account, HealthFunderOrganization organization, Enterprise enterprise, EcoSystem system) {
        initComponents();
        this.userProcessContainer=userProcessContainer;
        this.account=account;
        this.system=system;
        this.organization=organization;
        this.enterprise=enterprise;
        
        
       populateTable();
       for(FundWorkRequest req: system.getFundWorkQueue().getWorkRequestList())
        {
            if(req.getMessage().equalsIgnoreCase("Health Done"))
                populateTable2();
        }
       
       populateTable3();
      
        
    }
    
    int FundAvailable=100000;
    int fundreq;
    int fundleft=FundAvailable;
    public int cal(){
    for(FundWorkRequest r : system.getFundWorkQueue().getWorkRequestList())
            if(r instanceof  QuotationAnsWorkRequest)
            if(r.getMessage().equalsIgnoreCase("Hea")){
    fundreq=((QuotationAnsWorkRequest) r).getFund();
    fundleft=FundAvailable-fundreq;
            }
    return fundleft;
                }   
    
    public void populateTable(){
        DefaultTableModel model = (DefaultTableModel)Table1.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
            if(request instanceof  QuotationAnsWorkRequest)
                if(request.getMessage().equalsIgnoreCase("Hea"))
                    for(UserAccount a: ((QuotationAnsWorkRequest) request).getSen1())
            {
           
                
            Object[] row = new Object[6];   
            
            row[0] = a.getEmployee().getName();
            row[1] = request.getReceiver() == null ? null : request.getReceiver().getEmployee().getName();
            row[2] = request;
            row[3] = ((QuotationAnsWorkRequest) request).getFund();
            row[4] = fundleft;
            row[5] = request.getReqId();
            
            model.addRow(row);
        
        }
    }
       
       public void populateTable1(){
        DefaultTableModel model = (DefaultTableModel)Table1.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
            
                if(request.getMessage().equalsIgnoreCase("Hea Funds Doing"))
                    for(UserAccount a: ((QuotationAnsWorkRequest) request).getSen1())
            {
           
                
            Object[] row = new Object[6];   
            
            row[0] = a.getEmployee().getName();
            row[1] = request.getReceiver();
            row[2] = request;
            row[3] = ((QuotationAnsWorkRequest) request).getFund();
            row[4] = fundleft;
            row[5] = request.getReqId();
            model.addRow(row);
        
        }
    }
       public void populateTable2(){
        DefaultTableModel model = (DefaultTableModel)Table1.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
                            if(request.getMessage().equalsIgnoreCase("Hea Done"))
                    for(UserAccount a: ((QuotationAnsWorkRequest) request).getSen1())
            {
           
                
            Object[] row = new Object[6];   
            
            row[0] = a.getEmployee().getName();
            row[1] = request.getReceiver();
            row[2] = request;
            row[3] = ((QuotationAnsWorkRequest) request).getFund();
            row[4] = fundleft;
            row[5] = request.getReqId();
            model.addRow(row);
        
        }
    }
       public void populateTable3(){
        DefaultTableModel model = (DefaultTableModel)Table3.getModel();
        
        model.setRowCount(0);
        
        for(FundWorkRequest request : system.getFundWorkQueue().getWorkRequestList())
            if(request instanceof  ServiceRequestWorkrequest)
                if(request.getMessage().equalsIgnoreCase("Health"))
            {
           
                
            Object[] row = new Object[6];   
            
            row[0] = request.getSender().getEmployee().getName();
            row[1] = request.getReceiver() == null ? null : request.getReceiver().getEmployee().getName();
            row[2] = request;
            row[3] = request.getReqId();
            model.addRow(row);
        
        }
    }
    
    
     

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table1 = new javax.swing.JTable();
        assignBtn = new javax.swing.JButton();
        completeBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Table3 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEtchedBorder()), "RESPONSE FROM HEALTH SERVICES"));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Receiver", "Status", "Fund Required", "Fund Available", "Request Id"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Table1);
        if (Table1.getColumnModel().getColumnCount() > 0) {
            Table1.getColumnModel().getColumn(0).setResizable(false);
            Table1.getColumnModel().getColumn(1).setResizable(false);
            Table1.getColumnModel().getColumn(2).setResizable(false);
            Table1.getColumnModel().getColumn(3).setResizable(false);
            Table1.getColumnModel().getColumn(4).setResizable(false);
            Table1.getColumnModel().getColumn(5).setResizable(false);
        }

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 860, 220));

        assignBtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        assignBtn.setText("ASSIGN TO ME");
        assignBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        assignBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignBtnActionPerformed(evt);
            }
        });
        jPanel3.add(assignBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 150, 47));

        completeBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        completeBtn.setText("COMPLETE");
        completeBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        completeBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        completeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeBtnActionPerformed(evt);
            }
        });
        jPanel3.add(completeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 280, 157, 47));

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 960, 340));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEtchedBorder()), "REQUEST TO SERVICES"));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Reciver", "Status", "Request Id"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(Table3);
        if (Table3.getColumnModel().getColumnCount() > 0) {
            Table3.getColumnModel().getColumn(0).setResizable(false);
            Table3.getColumnModel().getColumn(1).setResizable(false);
            Table3.getColumnModel().getColumn(2).setResizable(false);
            Table3.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel4.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 540, 240));

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 260, 740, 330));

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("HEALTH FUNDER WORK AREA");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, 1022, 74));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/Funder/Education/css_icon_money-1.png"))); // NOI18N
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 130, 160));

        add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 1850, 200));
    }// </editor-fold>//GEN-END:initComponents

    private void assignBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignBtnActionPerformed
        // TODO add your handling code here:
        int selectedRow=Table1.getSelectedRow();
        if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
     return;
         }
        else
        {
            FundWorkRequest req=(FundWorkRequest)Table1.getValueAt(selectedRow,2);
            
             List<Integer> mini = new ArrayList<>();
            int minfund;
            for(FundWorkRequest request:system.getFundWorkQueue().getWorkRequestList())
            {
                if(request.getReqId().equalsIgnoreCase(req.getReqId()) && request.getReqName().equalsIgnoreCase(req.getReqName()) && request.getMessage().equalsIgnoreCase("Hea"))
                if(request.getFund()>0)
                mini.add(request.getFund());
            }
            minfund=Collections.min(mini);
            
            cal();
            if(fundleft>0){
            
            if(req.getMessage().equalsIgnoreCase("Hea") && req.getReceiver()==null){
              if(req.getFund()==minfund ) {
            req.setReceiver(account);
            req.setStatus("Processing");
            req.setMessage("Hea Funds Doing");
             for(FundWorkRequest request:system.getFundWorkQueue().getWorkRequestList())
             for(UserAccount a1:((QuotationAnsWorkRequest) req).getSen1())
            {
                if(req.getFund()==minfund && request.getReqId().equalsIgnoreCase(req.getReqId()) && request.getReqName().equalsIgnoreCase(req.getReqName()) )
                req.setFundCategory(a1.getEmployee().getName());
            } 
              
            
            ReportFundWorkRequest report = new ReportFundWorkRequest();
                     report.setStatus("Funds Granted");
                     report.setMessage("The Fund has been granted and forwarded the request to services.");
                     report.setSender(account);
                     report.setReqId(req.getReqId());
                     report.setReqEmp(req.getReqEmp());
                     report.setReqName(req.getReqName());
                     
                     organization.getFundWorkQueue().getWorkRequestList().add(report);
                     account.getFundWorkQueue().getWorkRequestList().add(report);
                     system.getFundWorkQueue().getWorkRequestList().add(report);
            populateTable1();
            
            }else{
                JOptionPane.showMessageDialog(null, "Please Process The Request with lower priority and least funds!!");
            }
            }
            
                else{
                JOptionPane.showMessageDialog(null, "The request cannot be completed twice");
            }
            }
            else{
                JOptionPane.showMessageDialog(null, "U Do not have enough funds to grant!!!!!");
            }
            
        }
    }//GEN-LAST:event_assignBtnActionPerformed

    private void completeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeBtnActionPerformed
        // TODO add your handling code here:
         int selectedRow= Table1.getSelectedRow();
         if(selectedRow<0){
             JOptionPane.showMessageDialog(null, "Please select the row to assign the account", "Warning", JOptionPane.WARNING_MESSAGE);
      }
         else{
             FundWorkRequest f=(FundWorkRequest)Table1.getValueAt(selectedRow, 2);
             if(f.getReceiver()!=null)
                 if(f.getStatus().equalsIgnoreCase("Processing")){
                     UserAccount a = f.getSender();
                     f.setStatus("Complete");
                     f.setMessage("Health Done");
                     
                ServiceRequestWorkrequest req= new ServiceRequestWorkrequest();
                req.setSender(account);
                req.setStatus("Request For Services Sent");
                req.setMessage("Health");
                req.setReqId(f.getReqId());
                req.setFundCategory(f.getFundCategory());
                req.setReqEmp(f.getReqEmp());
                req.setReqName(f.getReqName());
                req.setFund(f.getFund());
                organization.getFundWorkQueue().getWorkRequestList().add(req);
                account.getFundWorkQueue().getWorkRequestList().add(req);
                system.getFundWorkQueue().getWorkRequestList().add(req);
                     JOptionPane.showMessageDialog(null, "You have successfully completed and Forwaded a Services Request!!!");
                     populateTable2();
                     populateTable3();
                 }
                     else{
                     JOptionPane.showMessageDialog(null, "Cannot Complete the Request Twice!!!");
                             
                             }
                     
             
         }
    }//GEN-LAST:event_completeBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Table1;
    private javax.swing.JTable Table3;
    private javax.swing.JButton assignBtn;
    private javax.swing.JButton completeBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
