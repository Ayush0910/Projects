/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;


import Business.Donation.DonationDetailsDirectory;
import Business.EducationDetails.DetailsDirectory;
import Business.Employee.EmployeeDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.Employee.EmployeeDirectory;
import Business.EventInfo.EventInfoDirectory;
import Business.EventWorkQueue.EventWorkQueue;
import Business.FundWorkQueue.FundWorkQueue;
import Business.HealthDetails.HDetailsDirectory;
import Business.InvWorkQueue.InvWorkQueue;
import Business.NGOInventory.NGOInventoryDirectory;
import Business.Person.PersonDirectory;
import Business.SocialIssues.SocialIssuesDirectory;
import Business.UtilityWorkQueue.UtilityWorkQueue;

import Business.WorkQueue.WorkQueue;

import java.util.HashSet;

/**
 *
 * @author shwet
 */
public abstract class Organization {
    private String name;
    private WorkQueue workQueue;
    private EventWorkQueue eventWorkQueue;
    private FundWorkQueue fundWorkQueue;
    private EmployeeDirectory employeeDirectory;
   private PersonDirectory personDirectory;
    private UserAccountDirectory userAccountDirectory;
    private EventInfoDirectory eventInfoDirectory;
    private UtilityWorkQueue utilityWorkQueue;
    private NGOInventoryDirectory ngoInventoryDirectory;
    private SocialIssuesDirectory socialIssuesDirectory;
    private DonationDetailsDirectory donationDetailsDirectory;
    private InvWorkQueue invWorkQueue;
    private int organizationID;
   
    
    private static int counter=1;
    public HashSet<Role> roles;
    
    public enum Type{
        NgoCreate("Create"),NgoTask("Task"),NgoHealth("Health Department"), NgoEducation("education Department"),NgoGeneral("General Department"),Health("Health Funder Organization"),Rehabilitation("Rehab Funder Organization"),Education("Education Funder Organization"),HealthServices("Health Clinic Organization"),RehabilitationServices("Rehab Centres Organization"),EducationServices("Education Institution Organization");
        private String value;
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }
   

    public Organization(String name) {
        this.name = name;
        workQueue = new WorkQueue();
        eventWorkQueue=new EventWorkQueue();
        fundWorkQueue=new FundWorkQueue();
       personDirectory=new PersonDirectory();
        userAccountDirectory = new UserAccountDirectory();
        employeeDirectory = new EmployeeDirectory();
        eventInfoDirectory = new EventInfoDirectory();
        utilityWorkQueue= new UtilityWorkQueue();
        ngoInventoryDirectory = new NGOInventoryDirectory();
        socialIssuesDirectory = new SocialIssuesDirectory();
        invWorkQueue = new InvWorkQueue();
        donationDetailsDirectory = new DonationDetailsDirectory();
                organizationID = counter;
        roles = new HashSet<>();
        counter++;
    }

    public abstract HashSet<Role> getSupportedRole();

    public EventInfoDirectory getEventInfoDirectory() {
        return eventInfoDirectory;
    }

    public EventWorkQueue getEventWorkQueue() {
        return eventWorkQueue;
    }

    public void setEventWorkQueue(EventWorkQueue eventWorkQueue) {
        this.eventWorkQueue = eventWorkQueue;
    }

    public FundWorkQueue getFundWorkQueue() {
        return fundWorkQueue;
    }

    public UtilityWorkQueue getUtilityWorkQueue() {
        return utilityWorkQueue;
    }

    public NGOInventoryDirectory getNgoInventoryDirectory() {
        return ngoInventoryDirectory;
    }

    public SocialIssuesDirectory getSocialIssuesDirectory() {
        return socialIssuesDirectory;
    }

    public InvWorkQueue getInvWorkQueue() {
        return invWorkQueue;
    }

    public void setInvWorkQueue(InvWorkQueue invWorkQueue) {
        this.invWorkQueue = invWorkQueue;
    }

    public DonationDetailsDirectory getDonationDetailsDirectory() {
        return donationDetailsDirectory;
    }

    public void setDonationDetailsDirectory(DonationDetailsDirectory donationDetailsDirectory) {
        this.donationDetailsDirectory = donationDetailsDirectory;
    }

    public PersonDirectory getPersonDirectory() {
        return personDirectory;
    }
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    

    

    

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

   
    
    public String getName() {
        return name;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    @Override
    public String toString() {
        return name;
    }
 
}
