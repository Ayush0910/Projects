/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;

/**
 *
 * @author Rishika
 */
public abstract class Role {
    
    public enum RoleType{
        
        //once organization is done there will be changes in other classes in this package
        SystemAdmin("System Admin"), 
        NGOAdmin("NGO Admin"), 
        FunderAdmin("Funder Admin"), 
        ServicesAdmin("Services Admin"), 
        HealthFunderAdmin("Health Funder Admin"),
        RehabFunderAdmin("Rehab Funder Admin"), 
        EducationFunderAdmin("Education Funder Admin"), 
        HealthClinicAdmin("Health Clinic Admin"), 
        EducationalInstitutionAdmin("Educational Institution Admin"), 
        RehabCenterAdmin("Rehab Center Admin"),
        NgoHealth("Health"),
        NgoEducation("Education"),
        NgoRehab("Rehab"),
        NgoTask("Task Admin"),
        NgoCreate("Create Admin");
        
        
        private String value;
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }

        
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccount account, 
            Organization organization, 
            Enterprise enterprise, 
            EcoSystem business);

    @Override
    public String toString() {
        return this.getClass().getName();
    }
    
    
}