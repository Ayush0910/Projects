/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.HealthClinicOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.Services.Health.ServicesHealthAdminWorkArea;
import javax.swing.JPanel;

/**
 *
 * @author Rishika
 */
public class HealthClinicAdminRole extends Role {
    
     @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem system) {
        return new ServicesHealthAdminWorkArea(userProcessContainer, system,(HealthClinicOrganization) organization,account,enterprise);
    
     
}
     @Override
    public String toString(){
        return Role.RoleType.HealthClinicAdmin.getValue();
    }  
}
