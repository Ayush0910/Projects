/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.NgoTaskOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.NGO.Task.NgoTaskWorkArea;
import javax.swing.JPanel;

/**
 *
 * @author shwet
 */
public class NgoTask extends Role{
      @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem system) {
        return new NgoTaskWorkArea(userProcessContainer, system,account,organization,enterprise);
    }
    
     @Override
    public String toString(){
        return Role.RoleType.NgoTask.getValue();
    }
}
