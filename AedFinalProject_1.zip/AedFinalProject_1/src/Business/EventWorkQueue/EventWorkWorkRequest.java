/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EventWorkQueue;

import Business.UserAccount.UserAccount;
import Business.WorkQueue.*;
import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class EventWorkWorkRequest extends EventWorkRequest {
     private boolean testResult;
     private ArrayList<UserAccount> rec;
    
     public EventWorkWorkRequest()
     {
         testResult=false;
         rec = new ArrayList<>();
     }

    public boolean isTestResult() {
        return testResult;
    }

    public void setTestResult(boolean testResult) {
        this.testResult = testResult;
    }

    public ArrayList<UserAccount> getRec() {
        return rec;
    }

    public void setRec(ArrayList<UserAccount> rec) {
        this.rec = rec;
    }

   
    
    
}
