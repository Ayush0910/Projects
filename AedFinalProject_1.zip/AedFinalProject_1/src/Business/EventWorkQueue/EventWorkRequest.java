/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EventWorkQueue;


import Business.WorkQueue.*;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author maila
 */
public abstract class EventWorkRequest {

    private String message;
    private UserAccount sender;
    private ArrayList<UserAccount> receiver;
    private String status;
    private Date requestDate;
    private Date resolveDate;
    private int vol; 
    private String Category;
    
    public EventWorkRequest(){
        requestDate = new Date();
        receiver= new ArrayList<>();
        
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public ArrayList<UserAccount> getReceiver() {
        return receiver;
    }

    public void setReceiver(ArrayList<UserAccount> receiver) {
        this.receiver = receiver;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    

    

   
    

    

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }
    
    @Override
    public String toString(){
            return message;
    }

    public int getVol() {
        return vol;
    }

    public void setVol(int vol) {
        this.vol = vol;
    }
}
