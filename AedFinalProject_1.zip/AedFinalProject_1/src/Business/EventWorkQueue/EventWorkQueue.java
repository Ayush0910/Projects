/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EventWorkQueue;

import Business.WorkQueue.*;
import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class EventWorkQueue {
    
    private ArrayList<EventWorkRequest> workRequestList;

    public EventWorkQueue() {
        workRequestList = new ArrayList<>();
    }

    public ArrayList<EventWorkRequest> getWorkRequestList() {
        return workRequestList;
    }

    
}