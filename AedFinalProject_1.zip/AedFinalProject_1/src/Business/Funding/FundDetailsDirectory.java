/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Funding;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class FundDetailsDirectory {
    private ArrayList<FundDetails> fundDetailsDirectory;

    public FundDetailsDirectory() {
        fundDetailsDirectory= new ArrayList<FundDetails>();
        
    }

    public ArrayList<FundDetails> getFundDetailsDirectory() {
        return fundDetailsDirectory;
    }

    public void setFundDetailsDirectory(ArrayList<FundDetails> fundDetailsDirectory) {
        this.fundDetailsDirectory = fundDetailsDirectory;
    }
    
    
}
