/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.HealthDetails;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class HDetailsDirectory {
   private ArrayList<HDetails> hdetailsDirectory;
   
   public HDetailsDirectory()
   {
       hdetailsDirectory = new ArrayList<>();
   }

    public ArrayList<HDetails> getHdetailsDirectory() {
        return hdetailsDirectory;
    }

    public void setHdetailsDirectory(ArrayList<HDetails> hdetailsDirectory) {
        this.hdetailsDirectory = hdetailsDirectory;
    }
   
    public HDetails addHDetails(String heaStatus, String pastIssue, String pastReason, String history, String doctor,String severReason)
    {
        HDetails d= new HDetails();
        d.setHealthCondition(heaStatus);
        d.setPastIssues(pastIssue);
        d.setPastCondition(pastReason);
        d.setFamilyHistory(history);
        d.setDoctor(doctor);
               d.setSevereReason(severReason);
        hdetailsDirectory.add(d);
        return d;
    }
    
}
