/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.HealthDetails;

/**
 *
 * @author shwet
 */
public class HDetails {
    private String healthCondition;
    private String pastIssues;
    private String pastCondition;
    private String familyHistory;
    private String doctor;
    private String severeReason;
    public String getHealthCondition() {
        return healthCondition;
    }

    public void setHealthCondition(String healthCondition) {
        this.healthCondition = healthCondition;
    }

    public String getPastIssues() {
        return pastIssues;
    }

    public void setPastIssues(String pastIssues) {
        this.pastIssues = pastIssues;
    }

    public String getPastCondition() {
        return pastCondition;
    }

    public void setPastCondition(String pastCondition) {
        this.pastCondition = pastCondition;
    }

    public String getFamilyHistory() {
        return familyHistory;
    }

    public void setFamilyHistory(String familyHistory) {
        this.familyHistory = familyHistory;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

       public String getSevereReason() {
        return severeReason;
    }

    public void setSevereReason(String severeReason) {
        this.severeReason = severeReason;
    }
    
    
    
    
}
