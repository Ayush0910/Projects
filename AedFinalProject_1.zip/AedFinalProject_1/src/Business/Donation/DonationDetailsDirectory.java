/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Donation;


import Business.Person.Person;
import java.util.ArrayList;

/**
 *
 * @author Rishika
 */
public class DonationDetailsDirectory {
    
    private ArrayList<DonationDetails> donationDetailsList;
    
    public DonationDetailsDirectory() {
        donationDetailsList = new ArrayList<>();
    }

    public ArrayList<DonationDetails> getDonationDetailsList() {
        return donationDetailsList;
    }

    public void setDonationDetailsList(ArrayList<DonationDetails> donationDetailsList) {
        this.donationDetailsList = donationDetailsList;
    }
    
        public DonationDetails addDetails(){
        DonationDetails donationDetails = new DonationDetails();
        donationDetailsList.add(donationDetails);
        return donationDetails;
    }
    
    public void deleteDetails(DonationDetails donationDetails){
        donationDetailsList.remove(donationDetails);
    }
}
    
    
