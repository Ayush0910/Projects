/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Donation;

/**
 *
 * @author Rishika
 */
public class DonationDetails {
    
    private int woollensQty;
    private int blanketsQty;
    private int umbrellasQty;
    private int clothesQty;
    private int snowBootsQty;
    private int groceryQty;
    private int stationaryQty;

    public int getWoollensQty() {
        return woollensQty;
    }

    public void setWoollensQty(int woollensQty) {
        this.woollensQty = woollensQty;
    }

    public int getBlanketsQty() {
        return blanketsQty;
    }

    public void setBlanketsQty(int blanketsQty) {
        this.blanketsQty = blanketsQty;
    }

    public int getUmbrellasQty() {
        return umbrellasQty;
    }

    public void setUmbrellasQty(int umbrellasQty) {
        this.umbrellasQty = umbrellasQty;
    }

    public int getClothesQty() {
        return clothesQty;
    }

    public void setClothesQty(int clothesQty) {
        this.clothesQty = clothesQty;
    }

    public int getSnowBootsQty() {
        return snowBootsQty;
    }

    public void setSnowBootsQty(int snowBootsQty) {
        this.snowBootsQty = snowBootsQty;
    }

    public int getGroceryQty() {
        return groceryQty;
    }

    public void setGroceryQty(int groceryQty) {
        this.groceryQty = groceryQty;
    }

    public int getStationaryQty() {
        return stationaryQty;
    }

    public void setStationaryQty(int stationaryQty) {
        this.stationaryQty = stationaryQty;
    }
    
    
}
