/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.PhysicalDetails;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class PhysicalDetailsDirectory {
    
    private ArrayList<PhysicalDetails> physicalDetailsDirectory;
    
    
    public PhysicalDetailsDirectory(){
        physicalDetailsDirectory= new ArrayList<>();
        
    }

    public ArrayList<PhysicalDetails> getPhysicalDetailsDirectory() {
        return physicalDetailsDirectory;
    }

    public void setPhysicalDetailsDirectory(ArrayList<PhysicalDetails> physicalDetailsDirectory) {
        this.physicalDetailsDirectory = physicalDetailsDirectory;
    }
    
    public PhysicalDetails addDetails(){
        PhysicalDetails p= new PhysicalDetails();
        physicalDetailsDirectory.add(p);
        return p;
    }
}
