/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.General;

import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class GeneralDirectory {
 private ArrayList<General> generalDirectory;
 
 public GeneralDirectory()
 {
     generalDirectory = new ArrayList<>();
 }

    public ArrayList<General> getGeneralDirectory() {
        return generalDirectory;
    }

    public void setGeneralDirectory(ArrayList<General> generalDirectory) {
        this.generalDirectory = generalDirectory;
    }
 
 public General addDetails()
 {
     General gen = new General();
     generalDirectory.add(gen);
     return gen;
 }
}
