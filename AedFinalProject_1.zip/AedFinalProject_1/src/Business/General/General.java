/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.General;

/**
 *
 * @author maila
 */
public class General {
  private String drugTaken;
  private String drugTime;
  private String sexualAssault;
  private String sexualTime;
  private String depression;
  private String suicide;
  private String stress;
  

    public String getDrugTaken() {
        return drugTaken;
    }

    public void setDrugTaken(String drugTaken) {
        this.drugTaken = drugTaken;
    }

    public String getDrugTime() {
        return drugTime;
    }

    public void setDrugTime(String drugTime) {
        this.drugTime = drugTime;
    }

    public String getSexualAssault() {
        return sexualAssault;
    }

    public void setSexualAssault(String sexualAssault) {
        this.sexualAssault = sexualAssault;
    }

    public String getSexualTime() {
        return sexualTime;
    }

    public void setSexualTime(String sexualTime) {
        this.sexualTime = sexualTime;
    }

    public String getDepression() {
        return depression;
    }

    public void setDepression(String depression) {
        this.depression = depression;
    }

    public String getSuicide() {
        return suicide;
    }

    public void setSuicide(String suicide) {
        this.suicide = suicide;
    }

    public String getStress() {
        return stress;
    }

    public void setStress(String stress) {
        this.stress = stress;
    }
  
    
  
}
