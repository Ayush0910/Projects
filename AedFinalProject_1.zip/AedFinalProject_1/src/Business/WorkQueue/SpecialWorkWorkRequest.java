/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author maila
 */
public class SpecialWorkWorkRequest extends WorkRequest {
     private boolean testResult;

     public SpecialWorkWorkRequest()
     {
         testResult=false;
     }

    public boolean isTestResult() {
        return testResult;
    }

    public void setTestResult(boolean testResult) {
        this.testResult = testResult;
    }
    
}
