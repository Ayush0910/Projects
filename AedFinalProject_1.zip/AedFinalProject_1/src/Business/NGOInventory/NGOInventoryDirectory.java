/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.NGOInventory;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class NGOInventoryDirectory {
    
    
    private ArrayList<NGOInventory> ngoInventoryDirectory;
    
    
    public NGOInventoryDirectory(){
        ngoInventoryDirectory= new ArrayList<>();
    }

    public ArrayList<NGOInventory> getNgoInventoryDirectory() {
        return ngoInventoryDirectory;
    }

    public void setNgoInventoryDirectory(ArrayList<NGOInventory> ngoInventoryDirectory) {
        this.ngoInventoryDirectory = ngoInventoryDirectory;
    }
    
     public NGOInventory addDetails(){
        NGOInventory inv = new NGOInventory();
        ngoInventoryDirectory.add(inv);
        return inv;
    }
    public int penTotal()
    {
        int tpen=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            tpen=tpen+inv.getPen();
        }  
         return tpen;   
    }   
    public int pencilTotal()
    {
        int tpencil=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            tpencil=tpencil+inv.getPencil();
        }  
         return tpencil;   
    } 
     public int paperTotal()
    {
        int tpaper=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            tpaper=tpaper+inv.getPaper();
        }  
         return tpaper;   
    } 
    public int clothTotal()
    {
        int tcloth=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            tcloth=tcloth+inv.getCloth();
        }  
         return tcloth;   
    } 
    public int chairsTotal()
    {
        int tchairs=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            tchairs=tchairs+inv.getChairs();
        }  
         return tchairs;   
    } 
    public int tableTotal()
    {
        int ttable=0;
        for(NGOInventory inv : ngoInventoryDirectory)
        {
            ttable=ttable+inv.getTable();
        }  
         return ttable;   
    } 
}
