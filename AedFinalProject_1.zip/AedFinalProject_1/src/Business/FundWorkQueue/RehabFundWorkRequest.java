/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.FundWorkQueue;

/**
 *
 * @author maila
 */
public class RehabFundWorkRequest extends FundWorkRequest  {
   private boolean testResult;
     private String institute;
    
     
     public RehabFundWorkRequest()
     {
         testResult=false;
     }

    public boolean isTestResult() {
        return testResult;
    }

    public void setTestResult(boolean testResult) {
        this.testResult = testResult;
    }

    public String getInstitute() {
        return institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }  
}
