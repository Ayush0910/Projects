/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.FundWorkQueue;

/**
 *
 * @author maila
 */
public class HealthFundWorkRequest extends FundWorkRequest {
    private boolean testResult;
     private String type;
    
     
     public HealthFundWorkRequest()
     {
         testResult=false;
     }

    public boolean isTestResult() {
        return testResult;
    }

    public void setTestResult(boolean testResult) {
        this.testResult = testResult;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    
}
