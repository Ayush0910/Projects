/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.FundWorkQueue;


import Business.WorkQueue.*;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author maila
 */
public abstract class FundWorkRequest {

    private String message;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private Date requestDate;
    private Date resolveDate;
    private int priority;
    private String category;
    private ArrayList<UserAccount> rec;
    private ArrayList<UserAccount> sen;
    private int fund;
    private String reqName;
    private String reqId;
    private String fundCategory;
    private String reqEmp;
    private String priMsg;
    
    
    public FundWorkRequest(){
        requestDate = new Date();
        rec=new ArrayList<>();
        sen=new ArrayList<>();
    }

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public String getPriMsg() {
        return priMsg;
    }

    public void setPriMsg(String priMsg) {
        this.priMsg = priMsg;
    }

   

    public String getFundCategory() {
        return fundCategory;
    }

    public void setFundCategory(String fundCategory) {
        this.fundCategory = fundCategory;
    }

    public String getReqEmp() {
        return reqEmp;
    }

    public void setReqEmp(String reqEmp) {
        this.reqEmp = reqEmp;
    }

    

   

    

    
    
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getFund() {
        return fund;
    }

    public void setFund(int fund) {
        this.fund = fund;
    }

    public ArrayList<UserAccount> getSen() {
        return sen;
    }

    public void setSen(ArrayList<UserAccount> sen) {
        this.sen = sen;
    }

   
    

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public ArrayList<UserAccount> getRec() {
        return rec;
    }

    public void setRec(ArrayList<UserAccount> rec) {
        this.rec = rec;
    }
    
    
    
    @Override
    public String toString(){
            return status;
    }
}
