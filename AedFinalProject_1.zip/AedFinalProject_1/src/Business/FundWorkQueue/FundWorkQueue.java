/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.FundWorkQueue;

import Business.WorkQueue.*;
import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class FundWorkQueue {
    
    private ArrayList<FundWorkRequest> workRequestList;

    public FundWorkQueue() {
        workRequestList = new ArrayList<>();
    }

    public ArrayList<FundWorkRequest> getWorkRequestList() {
        return workRequestList;
    }

    
}