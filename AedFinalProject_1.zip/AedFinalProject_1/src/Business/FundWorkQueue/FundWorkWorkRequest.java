/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.FundWorkQueue;

import Business.EducationDetails.Details;
import java.util.ArrayList;



/**
 *
 * @author maila
 */
public class FundWorkWorkRequest extends FundWorkRequest {
     private String testResult;
     
        
    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    
    
    

    

    
    
    
}
