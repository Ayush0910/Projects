/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EventInfo;

import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class EventInfoDirectory {
   private ArrayList<EventInfo> eventInfoDirectory;

    public EventInfoDirectory() {
        eventInfoDirectory = new ArrayList<>();
        
    }

    public ArrayList<EventInfo> getEventInfoDirectory() {
        return eventInfoDirectory;
    }

    public void setEventInfoDirectory(ArrayList<EventInfo> eventInfoDirectory) {
        this.eventInfoDirectory = eventInfoDirectory;
    }
   
    public EventInfo addEvent()
    {
        EventInfo event=new EventInfo();
        eventInfoDirectory.add(event);
        return event;
    }
   
   
}
