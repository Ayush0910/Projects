/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EventInfo;

import Business.Organization.Organization;
import java.util.Date;

/**
 *
 * @author maila
 */
public class EventInfo {
    private Date date;
    private String eventId;
    private static int ecount=1;
    private String category;
    private int volunteers;
    private int audience;
    private String description;
    private String location;
    
    
    public EventInfo()
            {
         eventId="Eve"+ecount;
        ecount++;
            }
    public Date getDate() {
        
              return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEventId() {
        return eventId;
    }

   

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    

    public int getVolunteers() {
        return volunteers;
    }

    public void setVolunteers(int volunteers) {
        this.volunteers = volunteers;
    }

    public int getAudience() {
        return audience;
    }

    public void setAudience(int audience) {
        this.audience = audience;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    @Override
    public String toString()
    {
        return eventId;
    }
    
    
}
