/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.EducationDetails;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class DetailsDirectory {
   private ArrayList<Details> detailsDirectory;
   
   public DetailsDirectory()
   {
       detailsDirectory =new ArrayList<>();
       
   }

    public ArrayList<Details> getDetailsDirectory() {
        return detailsDirectory;
    }

    public void setDetailsDirectory(ArrayList<Details> detailsDirectory) {
        this.detailsDirectory = detailsDirectory;
    }
    
    public Details addDetails(String edu, String read,String write,String comm, String qaulify,String sus,String reason ){
        Details d = new Details();
        d.setSchool(edu);
        d.setRead(read);
        d.setWrite(write);
        d.setLanguage(comm);
        d.setQualification(qaulify);
        d.setSuspension(sus);
        d.setReason(reason);
        
        detailsDirectory.add(d);
        return d;
    }
}
