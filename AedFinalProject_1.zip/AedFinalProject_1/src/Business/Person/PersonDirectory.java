/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class PersonDirectory {
      private ArrayList<Person> personList;
      
    public PersonDirectory() {
        
        personList = new ArrayList<>();
        
    }

    public ArrayList<Person> getPersonList() {
        return personList;
    }

    public void setPersonList(ArrayList<Person> personList) {
        this.personList = personList;
    }
    
    public Person addPerson(String fname,String lname,String gender,Long phone,String address,int age,String empName){
        Person person = new Person();
        person.setFirstName(fname);
        person.setLastName(lname);
        person.setGender(gender);
        person.setPhoneNumber(phone);
        person.setAddress(address);
        person.setAge(age);
        person.setEmpName(empName);
        personList.add(person);
        return person;
    }
    
    
   
}
