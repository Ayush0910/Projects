/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;


import Business.EducationDetails.DetailsDirectory;
import Business.General.GeneralDirectory;
import Business.HealthDetails.HDetailsDirectory;
import Business.PhysicalDetails.PhysicalDetailsDirectory;
import Business.UtilitiesRequirements.UtilitiesDetailsDirectory;

/**
 *
 * @author maila
 */
public class Person {
    private String firstName;
    private String lastName;
    private long phoneNumber;
    private String address;
    private String gender;
    private int age;
    private String empName;
    private DetailsDirectory detailsDirectory;
    private HDetailsDirectory hDetailsDirectory;
    private PhysicalDetailsDirectory physicalDetailsDirectory;
    private GeneralDirectory generalDirectory;
    private UtilitiesDetailsDirectory utilitiesDetailsDirectory;
    private String Id;
    private static int percount=1;
    private int requestId;
    private String reqId;
    private String reqName;
    
    public Person()
    {
         
        Id="Id"+percount;
        percount++;
        detailsDirectory = new DetailsDirectory();
        hDetailsDirectory = new HDetailsDirectory();
        physicalDetailsDirectory = new PhysicalDetailsDirectory();
       generalDirectory = new GeneralDirectory();
        utilitiesDetailsDirectory = new UtilitiesDetailsDirectory();
    }

    public String getId() {
        return Id;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public UtilitiesDetailsDirectory getUtilitiesDetailsDirectory() {
        return utilitiesDetailsDirectory;
    }

    public void setUtilitiesDetailsDirectory(UtilitiesDetailsDirectory utilitiesDetailsDirectory) {
        this.utilitiesDetailsDirectory = utilitiesDetailsDirectory;
    }
    
    
    public DetailsDirectory getDetailsDirectory() {
        return detailsDirectory;
    }

    public void setDetailsDirectory(DetailsDirectory detailsDirectory) {
        this.detailsDirectory = detailsDirectory;
    }

    public HDetailsDirectory gethDetailsDirectory() {
        return hDetailsDirectory;
    }

    public void sethDetailsDirectory(HDetailsDirectory hDetailsDirectory) {
        this.hDetailsDirectory = hDetailsDirectory;
    }

    public PhysicalDetailsDirectory getPhysicalDetailsDirectory() {
        return physicalDetailsDirectory;
    }

    public void setPhysicalDetailsDirectory(PhysicalDetailsDirectory physicalDetailsDirectory) {
        this.physicalDetailsDirectory = physicalDetailsDirectory;
    }

    public GeneralDirectory getGeneralDirectory() {
        return generalDirectory;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }
    
    
  

    

    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    @Override
    public String toString()
    {
        return Id;
    }
    
}
