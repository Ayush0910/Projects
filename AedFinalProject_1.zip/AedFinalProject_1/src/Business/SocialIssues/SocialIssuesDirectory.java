/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.SocialIssues;

import java.util.ArrayList;

/**
 *
 * @author shwet
 */
public class SocialIssuesDirectory {
    
    
    private ArrayList <SocialIssues> socialIssuesDirectory;
    
    
    public SocialIssuesDirectory(){
        socialIssuesDirectory= new ArrayList<>();
        
    }

    public ArrayList<SocialIssues> getSocialIssuesDirectory() {
        return socialIssuesDirectory;
    }

    public void setSocialIssuesDirectory(ArrayList<SocialIssues> socialIssuesDirectory) {
        this.socialIssuesDirectory = socialIssuesDirectory;
    }
    public SocialIssues add()
    {
        SocialIssues iss=new SocialIssues();
        socialIssuesDirectory.add(iss);
        return iss;
    }
    
}
