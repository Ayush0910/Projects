/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.InvWorkQueue;

import Business.WorkQueue.*;
import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class InvWorkQueue {
    
    private ArrayList<InvWorkRequest> workRequestList;

    public InvWorkQueue() {
        workRequestList = new ArrayList<InvWorkRequest>();
    }

    public ArrayList<InvWorkRequest> getWorkRequestList() {
        return workRequestList;
    }

    
    
        
}

    
