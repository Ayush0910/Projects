/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.InvWorkQueue;

import Business.UtilityWorkQueue.*;



/**
 *
 * @author maila
 */
public class InvWorkWorkRequest extends InvWorkRequest {
     private int penrequestQuantity;
     private int paperrequestQuantity;
     private int pencilrequestQuantity;
     private int clothrequestQuantity;
     private int tablerequestQuantity;
     private int chairsrequestQuantity;
     
     
    private boolean add;
    
    public InvWorkWorkRequest(){
        add = false;
    }

    public int getPenrequestQuantity() {
        return penrequestQuantity;
    }

    public void setPenrequestQuantity(int penrequestQuantity) {
        this.penrequestQuantity = penrequestQuantity;
    }

    public int getPaperrequestQuantity() {
        return paperrequestQuantity;
    }

    public void setPaperrequestQuantity(int paperrequestQuantity) {
        this.paperrequestQuantity = paperrequestQuantity;
    }

    public int getPencilrequestQuantity() {
        return pencilrequestQuantity;
    }

    public void setPencilrequestQuantity(int pencilrequestQuantity) {
        this.pencilrequestQuantity = pencilrequestQuantity;
    }

    public int getClothrequestQuantity() {
        return clothrequestQuantity;
    }

    public void setClothrequestQuantity(int clothrequestQuantity) {
        this.clothrequestQuantity = clothrequestQuantity;
    }

    public int getTablerequestQuantity() {
        return tablerequestQuantity;
    }

    public void setTablerequestQuantity(int tablerequestQuantity) {
        this.tablerequestQuantity = tablerequestQuantity;
    }

    public int getChairsrequestQuantity() {
        return chairsrequestQuantity;
    }

    public void setChairsrequestQuantity(int chairsrequestQuantity) {
        this.chairsrequestQuantity = chairsrequestQuantity;
    }

   
    

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }
}
