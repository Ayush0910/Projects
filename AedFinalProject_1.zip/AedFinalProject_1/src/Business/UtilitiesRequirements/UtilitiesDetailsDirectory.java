/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UtilitiesRequirements;


import Business.Donation.*;
import java.util.ArrayList;

/**
 *
 * @author Rishika
 */
public class UtilitiesDetailsDirectory {
    
    private ArrayList<UtilitiesDetails> donationDetailsList;

    public UtilitiesDetailsDirectory() {
        donationDetailsList = new ArrayList<>();
    }

    public ArrayList<UtilitiesDetails> getDonationDetailsList() {
        return donationDetailsList;
    }

    public void setDonationDetailsList(ArrayList<UtilitiesDetails> donationDetailsList) {
        this.donationDetailsList = donationDetailsList;
    }
    
        public UtilitiesDetails addDetails(){
        UtilitiesDetails donationDetails = new UtilitiesDetails();
        donationDetailsList.add(donationDetails);
        return donationDetails;
    }
    
    public void deleteDetails(UtilitiesDetails donationDetails){
        donationDetailsList.remove(donationDetails);
    }

    
    
}
