/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.NgoEducation;
import Business.Role.NgoRehab;
import Business.Role.NgoHealth;
import Business.Role.Role;
import java.util.HashSet;

/**
 *
 * @author Rishika
 */
public class NgoEnterprise extends Enterprise{
    
      public NgoEnterprise(String name) {
        super(name, EnterpriseType.NGO);
    }
    
      
       @Override
    public HashSet<Role> getSupportedRole() {
        roles=new HashSet<>();
        roles.add(new NgoHealth());
        roles.add(new NgoRehab());
        roles.add(new NgoEducation());
        
        return roles;
    }
}
