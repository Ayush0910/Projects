/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.Employee.Employee;
import Business.EventWorkQueue.EventWorkQueue;
import Business.FundWorkQueue.FundWorkQueue;
import Business.InvWorkQueue.InvWorkQueue;
import Business.Role.Role;
import Business.UtilityWorkQueue.UtilityWorkQueue;
import Business.WorkQueue.WorkQueue;


/**
 *
 * @author maila
 */
public class UserAccount {
     private String username;
    private String password;
    private Employee employee;
    private Role role;
    private WorkQueue workQueue;
    private EventWorkQueue eventWorkQueue;
    private FundWorkQueue fundWorkQueue;
    private UtilityWorkQueue utilityWorkQueue;
    private InvWorkQueue invWorkQueue;
    
    public UserAccount() {
        workQueue = new WorkQueue();
       eventWorkQueue=new EventWorkQueue();
       fundWorkQueue=new FundWorkQueue();
       utilityWorkQueue = new UtilityWorkQueue();
       invWorkQueue = new InvWorkQueue();
    }

    public EventWorkQueue getEventWorkQueue() {
        return eventWorkQueue;
    }

    public FundWorkQueue getFundWorkQueue() {
        return fundWorkQueue;
    }

    public void setFundWorkQueue(FundWorkQueue fundWorkQueue) {
        this.fundWorkQueue = fundWorkQueue;
    }

    public UtilityWorkQueue getUtilityWorkQueue() {
        return utilityWorkQueue;
    }

    public InvWorkQueue getInvWorkQueue() {
        return invWorkQueue;
    }

   
    
    
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Employee getEmployee() {
        return employee;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    
    
    @Override
    public String toString() {
        return username;
    }
    
}
