/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UtilityWorkQueue;



/**
 *
 * @author maila
 */
public class UtilityWorkWorkRequest extends UtilityWorkRequest {
     private int woolrequestQuantity;
     private int blanketrequestQuantity;
     private int umbrellarequestQuantity;
     private int snowBootsrequestQuantity;
     private int clothesrequestQuantity;
     private int groceryrequestQuantity;
     private int stationeryrequestQuantity;
     
    private boolean add;
    
    public UtilityWorkWorkRequest(){
        add = false;
    }

    public int getWoolrequestQuantity() {
        return woolrequestQuantity;
    }

    public void setWoolrequestQuantity(int woolrequestQuantity) {
        this.woolrequestQuantity = woolrequestQuantity;
    }

    public int getBlanketrequestQuantity() {
        return blanketrequestQuantity;
    }

    public void setBlanketrequestQuantity(int blanketrequestQuantity) {
        this.blanketrequestQuantity = blanketrequestQuantity;
    }

    public int getUmbrellarequestQuantity() {
        return umbrellarequestQuantity;
    }

    public void setUmbrellarequestQuantity(int umbrellarequestQuantity) {
        this.umbrellarequestQuantity = umbrellarequestQuantity;
    }

    public int getSnowBootsrequestQuantity() {
        return snowBootsrequestQuantity;
    }

    public void setSnowBootsrequestQuantity(int snowBootsrequestQuantity) {
        this.snowBootsrequestQuantity = snowBootsrequestQuantity;
    }

    public int getClothesrequestQuantity() {
        return clothesrequestQuantity;
    }

    public void setClothesrequestQuantity(int clothesrequestQuantity) {
        this.clothesrequestQuantity = clothesrequestQuantity;
    }

    public int getGroceryrequestQuantity() {
        return groceryrequestQuantity;
    }

    public void setGroceryrequestQuantity(int groceryrequestQuantity) {
        this.groceryrequestQuantity = groceryrequestQuantity;
    }

    public int getStationeryrequestQuantity() {
        return stationeryrequestQuantity;
    }

    public void setStationeryrequestQuantity(int stationeryrequestQuantity) {
        this.stationeryrequestQuantity = stationeryrequestQuantity;
    }
    
    

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }
}
