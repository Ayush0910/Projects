/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UtilityWorkQueue;

import Business.WorkQueue.*;
import java.util.ArrayList;

/**
 *
 * @author maila
 */
public class UtilityWorkQueue {
    
    private ArrayList<UtilityWorkRequest> workRequestList;

    public UtilityWorkQueue() {
        workRequestList = new ArrayList<>();
    }

    public ArrayList<UtilityWorkRequest> getWorkRequestList() {
        return workRequestList;
    }

    
}