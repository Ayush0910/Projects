create view Club_details as 
select club_name,club_id,stadium_Name,capacity,Staff_Name,Roletype
 from club c Inner Join stadium s
 On c.club_id=s.clubid 
 Inner join 
 staffs f
 on c.club_id=f.clubid;
 
 select * from club_details;