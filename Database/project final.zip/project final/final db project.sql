-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: finalproject3
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `club`
--

DROP TABLE IF EXISTS `club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club` (
  `club_id` int(11) NOT NULL,
  `club_name` varchar(45) NOT NULL,
  PRIMARY KEY (`club_id`),
  UNIQUE KEY `club_id_UNIQUE` (`club_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club`
--

LOCK TABLES `club` WRITE;
/*!40000 ALTER TABLE `club` DISABLE KEYS */;
INSERT INTO `club` VALUES (1,'Chelsea'),(2,'Arsenal'),(3,'Manchester United'),(4,'Manchester city'),(5,'Liverpool'),(6,'Everton');
/*!40000 ALTER TABLE `club` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `club_details`
--

DROP TABLE IF EXISTS `club_details`;
/*!50001 DROP VIEW IF EXISTS `club_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `club_details` AS SELECT 
 1 AS `club_name`,
 1 AS `club_id`,
 1 AS `stadium_Name`,
 1 AS `capacity`,
 1 AS `Staff_Name`,
 1 AS `Roletype`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `club_merchandise`
--

DROP TABLE IF EXISTS `club_merchandise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_merchandise` (
  `Club_Id` int(11) NOT NULL,
  `Merchandise_Id` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`Club_Id`,`Merchandise_Id`),
  KEY `Club_Id` (`Club_Id`),
  KEY `Merchandise_Id` (`Merchandise_Id`),
  CONSTRAINT `club_merchandise_ibfk_1` FOREIGN KEY (`Club_Id`) REFERENCES `club` (`club_id`),
  CONSTRAINT `club_merchandise_ibfk_2` FOREIGN KEY (`Merchandise_Id`) REFERENCES `merchandise` (`Merchandise_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club_merchandise`
--

LOCK TABLES `club_merchandise` WRITE;
/*!40000 ALTER TABLE `club_merchandise` DISABLE KEYS */;
INSERT INTO `club_merchandise` VALUES (1,1,50),(1,2,15),(1,3,20),(1,4,30),(1,6,40),(2,1,80),(2,4,35),(2,5,10),(4,5,5),(6,3,50);
/*!40000 ALTER TABLE `club_merchandise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `club_schedule`
--

DROP TABLE IF EXISTS `club_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_schedule` (
  `club_id` int(11) NOT NULL,
  `WeekNo` int(11) NOT NULL,
  `Date` varchar(45) NOT NULL,
  `Location` varchar(45) NOT NULL,
  PRIMARY KEY (`club_id`),
  KEY `club_id` (`club_id`),
  CONSTRAINT `club_schedule_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club_schedule`
--

LOCK TABLES `club_schedule` WRITE;
/*!40000 ALTER TABLE `club_schedule` DISABLE KEYS */;
INSERT INTO `club_schedule` VALUES (1,1,'12-20-2017','Home'),(2,1,'12-20-2017','Home'),(3,2,'12-22-2017','Away'),(4,1,'12-20-2017','Home');
/*!40000 ALTER TABLE `club_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `club_sponsor`
--

DROP TABLE IF EXISTS `club_sponsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_sponsor` (
  `club_id` int(11) NOT NULL,
  `Sponsor_Id` int(11) NOT NULL,
  `Sponsorship_Value` int(11) NOT NULL,
  PRIMARY KEY (`club_id`,`Sponsor_Id`),
  KEY `club_id` (`club_id`),
  KEY `Sponsor_Id` (`Sponsor_Id`),
  CONSTRAINT `club_sponsor_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`),
  CONSTRAINT `club_sponsor_ibfk_2` FOREIGN KEY (`Sponsor_Id`) REFERENCES `sponsors` (`sponsor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club_sponsor`
--

LOCK TABLES `club_sponsor` WRITE;
/*!40000 ALTER TABLE `club_sponsor` DISABLE KEYS */;
INSERT INTO `club_sponsor` VALUES (1,1,2000),(1,3,7000),(2,1,1000),(3,1,2070),(4,3,600),(6,2,1000);
/*!40000 ALTER TABLE `club_sponsor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(45) DEFAULT NULL,
  `clubId` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `clubId` (`clubId`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Ayush',1),(2,'Shweta',1),(3,'Samarth',2),(4,'Kavin',1),(5,'Ketan',1),(6,'Ajad',2),(7,'Omkar',3),(8,'Roopak',4),(9,'Nihar',5),(10,'Kedar',3),(11,'Shreyas',6),(12,'Frenali',3),(13,'Shreya',3),(14,'Vartul',3);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_merchandise`
--

DROP TABLE IF EXISTS `customer_merchandise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_merchandise` (
  `cust_Id` int(11) NOT NULL,
  `Merchand_Id` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  KEY `merchandFk_idx` (`Merchand_Id`),
  KEY `cust_Id` (`cust_Id`),
  CONSTRAINT `customer_merchandise_ibfk_1` FOREIGN KEY (`cust_Id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `merchandFk` FOREIGN KEY (`Merchand_Id`) REFERENCES `merchandise` (`Merchandise_Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_merchandise`
--

LOCK TABLES `customer_merchandise` WRITE;
/*!40000 ALTER TABLE `customer_merchandise` DISABLE KEYS */;
INSERT INTO `customer_merchandise` VALUES (1,1,2),(2,4,5),(3,3,1),(7,1,2),(8,1,2),(10,2,2),(5,1,2);
/*!40000 ALTER TABLE `customer_merchandise` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger callTotal
After insert on customer_merchandise
for each row
begin

call total(New.cust_id);
End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `fixture_punishment`
--

DROP TABLE IF EXISTS `fixture_punishment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixture_punishment` (
  `fixtureID` int(11) NOT NULL,
  `PunishmentType` varchar(45) NOT NULL,
  `PlayerId` int(11) NOT NULL,
  KEY `fixtureID` (`fixtureID`),
  KEY `PunishmentType` (`PunishmentType`),
  KEY `PlayerId` (`PlayerId`),
  CONSTRAINT `fixture_punishment_ibfk_1` FOREIGN KEY (`fixtureID`) REFERENCES `fixtures` (`fixture_Id`),
  CONSTRAINT `fixture_punishment_ibfk_2` FOREIGN KEY (`PunishmentType`) REFERENCES `punishment` (`Punishment_Type`),
  CONSTRAINT `fixture_punishment_ibfk_3` FOREIGN KEY (`PlayerId`) REFERENCES `players` (`Player_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixture_punishment`
--

LOCK TABLES `fixture_punishment` WRITE;
/*!40000 ALTER TABLE `fixture_punishment` DISABLE KEYS */;
INSERT INTO `fixture_punishment` VALUES (1,'Red card',1),(3,'Yellow card',7),(4,'Yellow card',2);
/*!40000 ALTER TABLE `fixture_punishment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger callfixt
before insert on fixture_punishment
for each row
Begin
declare id Integer;
declare playId integer;
declare puntype varchar(20);
declare club1 Integer;
declare club2 Integer;
declare clubplay Integer;
Select fixtureid into Id from fixture_punishment where fixtureid=New.fixtureid;
select punishmentType into puntype from fixture_punishment where fixtureId=Id;
Select playerId into playId from fixture_punishment where fixtureID=Id;
Select clubId1 Into club1 from fixtures where fixture_id=id;
Select clubId2 Into club2 from fixtures where fixture_id=id;
select club_id Into clubplay from players where Player_id=playId;
if(clubplay IN(club1,club2))
Then
call fixture_entry(id,puntype,playId);
else
signal sqlstate '45000' set message_text ='The Player Has not played the match';
end if;
End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `fixtures`
--

DROP TABLE IF EXISTS `fixtures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixtures` (
  `fixture_Id` int(11) NOT NULL AUTO_INCREMENT,
  `clubId1` int(11) NOT NULL,
  `clubId2` int(11) NOT NULL,
  `Date` varchar(45) NOT NULL,
  `RefreeId` int(11) NOT NULL,
  `StadiumId` int(11) NOT NULL,
  `Result` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`fixture_Id`,`clubId1`,`clubId2`,`RefreeId`,`StadiumId`,`Date`),
  UNIQUE KEY `fixture_Id_UNIQUE` (`fixture_Id`),
  KEY `clubId1` (`clubId1`),
  KEY `clubId2` (`clubId2`),
  KEY `RefreeId` (`RefreeId`),
  KEY `StadiumId` (`StadiumId`),
  CONSTRAINT `fixtures_ibfk_1` FOREIGN KEY (`clubId1`) REFERENCES `club` (`club_id`),
  CONSTRAINT `fixtures_ibfk_2` FOREIGN KEY (`clubId2`) REFERENCES `club` (`club_id`),
  CONSTRAINT `fixtures_ibfk_3` FOREIGN KEY (`RefreeId`) REFERENCES `refree` (`refree_id`),
  CONSTRAINT `fixtures_ibfk_4` FOREIGN KEY (`StadiumId`) REFERENCES `stadium` (`Stadium_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixtures`
--

LOCK TABLES `fixtures` WRITE;
/*!40000 ALTER TABLE `fixtures` DISABLE KEYS */;
INSERT INTO `fixtures` VALUES (1,1,2,'12-15-2017',1,1,'1'),(3,1,5,'12-20-2017',5,5,'5'),(4,2,6,'12-20-2017',3,2,'2'),(22,5,6,'12-25-2017',1,5,'0'),(23,1,3,'12-25-2017',2,3,'0'),(25,2,4,'12-28-2017',2,2,'4'),(26,2,4,'12-29-2017',2,2,'4'),(27,3,5,'12-30-2017',2,3,'5'),(28,2,6,'12-31-2017',2,2,'2'),(29,1,4,'12-31-2017',1,1,'1'),(30,2,6,'12-21-2017',3,2,'6'),(31,1,4,'12-18-2017',1,1,'1'),(32,4,6,'12-23-2017',3,6,'4'),(33,3,2,'12-16-2017',2,3,'3'),(34,4,3,'12-15-2017',2,4,'0'),(35,1,2,'12-27-2017',2,1,'1');
/*!40000 ALTER TABLE `fixtures` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 Trigger  club_Entry
Before Insert on fixtures
for each row
Begin
if(New.Date In (Select Date from fixtures))
Then
If(New.clubId1 IN (select clubId1 from fixtures where date=New.Date) OR New.clubId2 IN (select clubId2 from fixtures where date=NEW.Date))
Then
signal sqlstate '45000' set message_text ='Club cannot have two fixtures on same day';
end if;
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 Trigger  Refree_Entry
Before Insert on fixtures
for each row
Begin
If(NEW.Date In (select Date from fixtures ))
Then
If(NEW.RefreeId  In (select RefreeId from fixtures where date=New.Date))
Then 
signal sqlstate '45000' set message_text = 'There Cannot be Two Refrees On same day';
end if;
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 Trigger  Stadium_Entry
Before Insert on fixtures
for each row
Begin
If(NEW.Date In (select Date from fixtures ))
Then
If(NEW.StadiumId  In (select StadiumId from fixtures where date=New.Date))
Then 
signal sqlstate '45000' set message_text = 'There Cannot be Two Stadium Used On same day';
end if;
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 Trigger  pointsTable_entry
After Insert on fixtures
for each row
Begin
declare id Integer;
declare club1 Integer;
declare club2 Integer;
declare clubName1 varchar(30);
declare clubName2 varchar(40);
declare won1 Integer;
declare won2 Integer;
declare played1 Integer;
declare played2 Integer;
declare Lost1 Integer;
declare Lost2 Integer;
declare Draw1 Integer;
declare Draw2 Integer;
declare TotalPoints1 integer;
declare TotalPoints2 integer;
if(New.fixture_id In (select fixture_id from fixtures))
Then
select result Into Id  from fixtures where New.fixture_id=fixture_id;
if(Id=0)
Then
select clubId1 Into club1 from fixtures where New.fixture_id=fixture_id;
select clubId2 Into club2 from fixtures where New.fixture_id=fixture_id;
select club_Name Into clubName1 from club where club_id=club1;
select club_Name Into clubName2 from club where club_id=club2;
select won Into won1 from points_table where club_name=clubName1;
select won Into won2 from points_table where club_name=clubName2;
select played Into played1 from points_table where club_name=clubName1;
select played Into played2 from points_table where club_name=clubName2;
select lost Into lost1 from points_table where club_name=clubName1;
select lost Into lost2 from points_table where club_name=clubName2;
select draw Into draw1 from points_table where club_name=clubName1;
select draw Into draw2 from points_table where club_name=clubName2;
select Total_Points Into TotalPoints1 from points_table where club_name=clubName1;
select Total_Points Into TotalPoints2 from points_table where club_name=clubName2;
Update  points_table
set played=played1+1,won=won1+0,lost=lost1+0,draw=draw1+1,Total_Points=TotalPoints1+1
where club_name=clubName1;
Update  points_table
set played=played1+1,won=won2+0,lost=lost2+0,draw=draw2+1,Total_Points=TotalPoints2+1
where club_name=clubName2;


end if;
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 Trigger  pointsTable_entryWin
After Insert on fixtures
for each row
Begin
declare id Integer;
declare id1 Integer;
declare club1 Integer;
declare club2 Integer;
declare clubName1 varchar(30);
declare clubName2 varchar(40);
declare won1 Integer;
declare won2 Integer;
declare played1 Integer;
declare played2 Integer;
declare Lost1 Integer;
declare Lost2 Integer;
declare Draw1 Integer;
declare Draw2 Integer;
declare TotalPoints1 integer;
declare TotalPoints2 integer;
if(New.fixture_id In (select fixture_id from fixtures))
Then
select result Into Id  from fixtures where New.fixture_id=fixture_id;
if(Id>0)
Then

select clubId1 Into club1 from fixtures where New.fixture_id=fixture_id;
select clubId2 Into club2 from fixtures where New.fixture_id=fixture_id;
if(club1=id)
Then 
set id1=club2;

select club_Name Into clubName1 from club where club_id=id;
select club_Name Into clubName2 from club where club_id=id1;
select won Into won1 from points_table where club_name=clubName1;
select won Into won2 from points_table where club_name=clubName2;
select played Into played1 from points_table where club_name=clubName1;
select played Into played2 from points_table where club_name=clubName2;
select lost Into lost1 from points_table where club_name=clubName1;
select lost Into lost2 from points_table where club_name=clubName2;
select draw Into draw1 from points_table where club_name=clubName1;
select draw Into draw2 from points_table where club_name=clubName2;
select Total_Points Into TotalPoints1 from points_table where club_name=clubName1;
select Total_Points Into TotalPoints2 from points_table where club_name=clubName2;
Update  points_table
set played=played1+1,won=won1+1,lost=lost1+0,draw=draw1+0,Total_Points=TotalPoints1+3
where club_name=clubName1;
Update  points_table
set played=played2+1,won=won2+0,lost=lost2+1,draw=draw2+0,Total_Points=TotalPoints2+0
where club_name=clubName2;

else 
set id1=club1;


select club_Name Into clubName1 from club where club_id=id1;
select club_Name Into clubName2 from club where club_id=id;
select won Into won1 from points_table where club_name=clubName1;
select won Into won2 from points_table where club_name=clubName2;
select played Into played1 from points_table where club_name=clubName1;
select played Into played2 from points_table where club_name=clubName2;
select lost Into lost1 from points_table where club_name=clubName1;
select lost Into lost2 from points_table where club_name=clubName2;
select draw Into draw1 from points_table where club_name=clubName1;
select draw Into draw2 from points_table where club_name=clubName2;
select Total_Points Into TotalPoints1 from points_table where club_name=clubName1;
select Total_Points Into TotalPoints2 from points_table where club_name=clubName2;
Update  points_table
set played=played1+1,won=won1+1,lost=lost1+0,draw=draw1+0,Total_Points=TotalPoints1+3
where club_name=clubName1;
Update  points_table
set played=played2+1,won=won2+0,lost=lost2+1,draw=draw2+0,Total_Points=TotalPoints2+0
where club_name=clubName2;

end if;
end if;
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `merchandise`
--

DROP TABLE IF EXISTS `merchandise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchandise` (
  `Merchandise_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Merchandise_Id`),
  UNIQUE KEY `Merchandise_Id_UNIQUE` (`Merchandise_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchandise`
--

LOCK TABLES `merchandise` WRITE;
/*!40000 ALTER TABLE `merchandise` DISABLE KEYS */;
INSERT INTO `merchandise` VALUES (1,'Tshirt'),(2,'Bag'),(3,'watch'),(4,'Jacket'),(5,'Cap'),(6,'Hoodie');
/*!40000 ALTER TABLE `merchandise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `players` (
  `Player_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Player_Name` varchar(45) NOT NULL,
  `Position` varchar(45) NOT NULL,
  `FootPreference` varchar(45) NOT NULL,
  `Club_id` int(11) NOT NULL,
  PRIMARY KEY (`Player_Id`,`Club_id`),
  UNIQUE KEY `Player_Id_UNIQUE` (`Player_Id`),
  KEY `Club_id` (`Club_id`),
  CONSTRAINT `players_ibfk_1` FOREIGN KEY (`Club_id`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (1,'Eden','Forward','Right',1),(2,'Morata','Forward','Right',1),(3,'Cahill','Defender','Right',1),(4,'Courtois','GoalKeeper','Left',1),(5,'Kante','MidFielder','Right',1),(6,'Ramsey','MidFielder','Right',2),(7,'Cech','GoalKeeper','Right',2),(8,'Ozil','Forward','Right',2),(9,'Lukaku','Forward','Left',3),(10,'Pogba','MidFielder','Right',3),(11,'Silva','MidFielder','Left',4),(12,'Sterling','MidFielder','Right',4),(13,'Salah','MidFielder','Left',5),(14,'Rooney','Forward','Right',6);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_table`
--

DROP TABLE IF EXISTS `points_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `points_table` (
  `Sr.No` int(11) NOT NULL AUTO_INCREMENT,
  `Club_Name` varchar(45) NOT NULL,
  `Played` int(11) DEFAULT NULL,
  `Won` int(11) DEFAULT NULL,
  `Lost` int(11) DEFAULT NULL,
  `Draw` int(12) DEFAULT NULL,
  `Total_Points` int(12) DEFAULT NULL,
  PRIMARY KEY (`Sr.No`),
  UNIQUE KEY `Sr.No_UNIQUE` (`Sr.No`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_table`
--

LOCK TABLES `points_table` WRITE;
/*!40000 ALTER TABLE `points_table` DISABLE KEYS */;
INSERT INTO `points_table` VALUES (1,'Chelsea',3,2,0,1,7),(2,'Arsenal',3,0,3,0,0),(3,'Manchester United',1,1,1,2,5),(4,'Manchester City',1,0,0,1,1),(5,'Liverpool',1,1,0,0,3),(6,'Everton',2,1,1,0,3);
/*!40000 ALTER TABLE `points_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `punishment`
--

DROP TABLE IF EXISTS `punishment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `punishment` (
  `Punishment_Type` varchar(50) NOT NULL,
  `Punishment_Length` varchar(45) NOT NULL,
  PRIMARY KEY (`Punishment_Type`),
  UNIQUE KEY `Punishment_Type_UNIQUE` (`Punishment_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `punishment`
--

LOCK TABLES `punishment` WRITE;
/*!40000 ALTER TABLE `punishment` DISABLE KEYS */;
INSERT INTO `punishment` VALUES ('red card','5'),('Yellow Card','2');
/*!40000 ALTER TABLE `punishment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refree`
--

DROP TABLE IF EXISTS `refree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refree` (
  `refree_id` int(11) NOT NULL AUTO_INCREMENT,
  `refree_name` varchar(45) NOT NULL,
  PRIMARY KEY (`refree_id`),
  UNIQUE KEY `refree_id_UNIQUE` (`refree_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refree`
--

LOCK TABLES `refree` WRITE;
/*!40000 ALTER TABLE `refree` DISABLE KEYS */;
INSERT INTO `refree` VALUES (1,'Mark'),(2,'Michael'),(3,'Matin'),(4,'Kevin'),(5,'Anthony');
/*!40000 ALTER TABLE `refree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `RoleType` varchar(45) NOT NULL,
  PRIMARY KEY (`RoleType`),
  UNIQUE KEY `RoleType_UNIQUE` (`RoleType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES ('management'),('Owner'),('Technical');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `Invoice_No` int(11) NOT NULL AUTO_INCREMENT,
  `CustId` int(11) NOT NULL,
  `Total_Amount` int(11) DEFAULT NULL,
  `clubId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Invoice_No`),
  UNIQUE KEY `Invoive_No_UNIQUE` (`Invoice_No`),
  KEY `clubId` (`clubId`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,7,50,3),(2,8,60,4),(3,10,80,3),(4,5,100,1);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsors`
--

DROP TABLE IF EXISTS `sponsors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsors` (
  `sponsor_id` int(11) NOT NULL AUTO_INCREMENT,
  `Sponsor_Name` varchar(45) NOT NULL,
  PRIMARY KEY (`sponsor_id`),
  UNIQUE KEY `sponsor_id_UNIQUE` (`sponsor_id`),
  UNIQUE KEY `Sponsor_Name_UNIQUE` (`Sponsor_Name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsors`
--

LOCK TABLES `sponsors` WRITE;
/*!40000 ALTER TABLE `sponsors` DISABLE KEYS */;
INSERT INTO `sponsors` VALUES (2,'Adidas'),(1,'Nike'),(3,'Puma'),(4,'Reebok');
/*!40000 ALTER TABLE `sponsors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stadium`
--

DROP TABLE IF EXISTS `stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stadium` (
  `Stadium_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Stadium_Name` varchar(45) NOT NULL,
  `Capacity` int(11) NOT NULL,
  `clubId` int(11) NOT NULL,
  PRIMARY KEY (`Stadium_Id`,`clubId`),
  KEY `clubId` (`clubId`),
  CONSTRAINT `stadium_ibfk_1` FOREIGN KEY (`clubId`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium`
--

LOCK TABLES `stadium` WRITE;
/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` VALUES (1,'Stamford Bridge',40000,1),(2,'Emirates',60000,2),(3,'old trafford',80000,3),(4,'Ethiad',44000,4),(5,'Anfield',70000,5),(6,'Goodison Park',39000,6);
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stadium_address`
--

DROP TABLE IF EXISTS `stadium_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stadium_address` (
  `ZipCode` int(11) NOT NULL,
  `Stadium_Id` int(11) NOT NULL,
  `Street` varchar(50) NOT NULL,
  `City` varchar(45) NOT NULL,
  `State` varchar(45) NOT NULL,
  PRIMARY KEY (`ZipCode`,`Stadium_Id`),
  UNIQUE KEY `ZipCode_UNIQUE` (`ZipCode`),
  UNIQUE KEY `Stadium_Id_UNIQUE` (`Stadium_Id`),
  CONSTRAINT `StadFk` FOREIGN KEY (`Stadium_Id`) REFERENCES `stadium` (`Stadium_Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium_address`
--

LOCK TABLES `stadium_address` WRITE;
/*!40000 ALTER TABLE `stadium_address` DISABLE KEYS */;
INSERT INTO `stadium_address` VALUES (11,1,'bridge','london','england'),(22,2,'north','london','england'),(33,3,'red','manchester','england'),(44,4,'blue','manchester','england'),(55,5,'liv','mersyside','england'),(66,6,'good','mersyside','england');
/*!40000 ALTER TABLE `stadium_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffs` (
  `Staff_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Staff_Name` varchar(45) NOT NULL,
  `Roletype` varchar(30) NOT NULL,
  `ClubId` int(11) NOT NULL,
  PRIMARY KEY (`Staff_Id`,`ClubId`,`Roletype`),
  UNIQUE KEY `Staff_Id_UNIQUE` (`Staff_Id`),
  KEY `clubFk_idx` (`ClubId`),
  KEY `roleFk_idx` (`Roletype`),
  CONSTRAINT `clubFk` FOREIGN KEY (`ClubId`) REFERENCES `club` (`club_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `roleFk` FOREIGN KEY (`Roletype`) REFERENCES `role` (`RoleType`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffs`
--

LOCK TABLES `staffs` WRITE;
/*!40000 ALTER TABLE `staffs` DISABLE KEYS */;
INSERT INTO `staffs` VALUES (1,'Roman','owner',1),(2,'Antonio','management',1),(3,'Emenalo','Technical',1),(5,'Stan','owner',2),(6,'Arsene','management',2),(7,'Chips','Technical',2),(8,'Malcolm','owner',3),(9,'Jose','management',3),(10,'Joel','Technical',3),(11,'Sheikh','owner',4),(12,'Pep','management',4),(13,'Aitor','Technical',4),(14,'Fenway','owner',5),(15,'Klopp','management',5),(16,'Edwards','Technical',5),(17,'Moshiri','owner',6),(18,'Sam','management',6),(19,'Kenwright','Technical',6);
/*!40000 ALTER TABLE `staffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `ticket_id` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  `Stad_Id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`,`Stad_Id`),
  UNIQUE KEY `ticket_id_UNIQUE` (`ticket_id`),
  KEY `Stad_Id` (`Stad_Id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`Stad_Id`) REFERENCES `stadium` (`Stadium_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES ('111A',300,3,5),('11A',115,2,5),('1A',100,1,NULL),('1B',200,1,5),('22A',275,2,3),('2A',150,1,5),('2B',250,1,5),('AA',250,4,5),('BB',150,5,5),('CC',300,6,5);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_sale`
--

DROP TABLE IF EXISTS `tickets_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_sale` (
  `ticket_id` varchar(30) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`,`cust_id`),
  UNIQUE KEY `ticket_id_UNIQUE` (`ticket_id`),
  KEY `CustFk_idx` (`cust_id`),
  CONSTRAINT `CustFk` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `TickFk` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`ticket_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_sale`
--

LOCK TABLES `tickets_sale` WRITE;
/*!40000 ALTER TABLE `tickets_sale` DISABLE KEYS */;
INSERT INTO `tickets_sale` VALUES ('1B',1,10),('22A',1,2),('2A',1,12);
/*!40000 ALTER TABLE `tickets_sale` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger checkTickets
Before Insert on tickets_sale
for each row
Begin
declare quant int;
declare quant1 int;
declare id varchar(20);
select ticket_id into id from tickets_sale where ticket_id=New.ticket_id;
Select quantity into quant from tickets where ticket_id= id;
select quantity into quant1 from tickets_sale where ticket_id=id;
if(quant1<quant)
Then

call ticketsales(id,quant1);

else
signal sqlstate '45000' set message_text ='U are selecting more than available quantity';
end if;

End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `tranfers_id` int(11) NOT NULL AUTO_INCREMENT,
  `playerId` int(11) NOT NULL,
  `clubId1` int(11) NOT NULL,
  `clubId2` int(11) NOT NULL,
  `Transfer_Value` int(11) NOT NULL,
  PRIMARY KEY (`tranfers_id`,`playerId`,`clubId1`,`clubId2`),
  UNIQUE KEY `tranfers_id_UNIQUE` (`tranfers_id`),
  KEY `playerId` (`playerId`),
  KEY `clubId1` (`clubId1`),
  KEY `clubId2` (`clubId2`),
  CONSTRAINT `transfers_ibfk_1` FOREIGN KEY (`playerId`) REFERENCES `players` (`Player_Id`),
  CONSTRAINT `transfers_ibfk_2` FOREIGN KEY (`clubId1`) REFERENCES `club` (`club_id`),
  CONSTRAINT `transfers_ibfk_3` FOREIGN KEY (`clubId2`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'finalproject3'
--

--
-- Dumping routines for database 'finalproject3'
--
/*!50003 DROP PROCEDURE IF EXISTS `fixture_entry` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fixture_entry`(in id int,in puntype varchar(20),in playId int)
Begin
insert into fixture_punishment values(id,puntype,playId);

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ticketsales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ticketsales`(in id varchar(20),in quant1 int)
begin
Select quantity Into quant1 from tickets_sale where ticket_id=id;
update tickets
set quantity=quantity-quant1
where ticket_id= id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `total` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `total`(in id int)
Begin

declare idm int;
declare quant int;
declare pri int;
declare custId int;
declare totalAmt int;
select merchand_id into idm from customer_merchandise where cust_id=id;
select quantity into quant from customer_merchandise where cust_id=id;
select clubId into custId from customer where customer_id=id;
select price into pri from club_merchandise where  Club_Id=custId AND Merchandise_id=idm ;
set totalAmt=pri*quant;
Insert into sales(custId,Total_Amount) Values (id,totalAmt);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `totalRevenue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `totalRevenue`()
begin
select club_Name,sum(Total_Amount) As Total_Sales,ClubId From sales Inner Join club where sales.clubId=club.club_id group by clubId;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `club_details`
--

/*!50001 DROP VIEW IF EXISTS `club_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `club_details` AS select `c`.`club_name` AS `club_name`,`c`.`club_id` AS `club_id`,`s`.`Stadium_Name` AS `stadium_Name`,`s`.`Capacity` AS `capacity`,`f`.`Staff_Name` AS `Staff_Name`,`f`.`Roletype` AS `Roletype` from ((`club` `c` join `stadium` `s` on((`c`.`club_id` = `s`.`clubId`))) join `staffs` `f` on((`c`.`club_id` = `f`.`ClubId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-14  5:46:14
